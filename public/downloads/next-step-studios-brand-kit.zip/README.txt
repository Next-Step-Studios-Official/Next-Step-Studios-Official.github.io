Next Step Studios — brand kit
Generated 2026-11-21

WHAT IS IN HERE

  README.txt    This file.
  current/      The live mark and the site's favicons. Use the mark files
                unless you specifically need an old one.
  archive/      Retired marks, kept because old posts and documents still use
                them. Each filename carries its retirement date, and the ZIP
                stores that date as the file's metadata too.

  Current logo  →  current/
    8 PNG, 4 JPG, 8 SVG
    Transparent master cut from the original white-tile artwork. The light outline treatment is for dark surfaces, where the black ninja would otherwise disappear.

  Retired neon orbit emblem  →  archive/
    4 PNG, 4 JPG, 4 SVG
    Retired 25 July 2026. Kept at stable addresses because older posts and documents still use it.

Every mark is supplied at 1024, 512, 256, 128 pixels, as:

  .png   Transparent. This is the file to use when the background is not known.
  .svg   An SVG wrapper around the transparent PNG at that size. It scales in
         layout without a blurry browser resize, but it is not a vector redraw
         of the artwork.
  .jpg   Flattened on the studio's dark base #07080B. JPG cannot store
         transparency, so these use the light-outline treatment: the black
         ninja and the black "STUDIOS" line would otherwise disappear.

The current mark also ships a "light" PNG and SVG for the same reason: on a
near-black surface the standard transparent mark loses its black areas. Use the
light treatment on dark, the standard transparent files on light.

WHICH FILE IS WHICH

  current/logo-<size>.png / .svg          Live logo, transparent, standard treatment.
  current/logo-<size>.jpg                 Live logo on #07080B, light outline.
  current/logo-light-<size>.png / .svg    Live logo, transparent, light outline.
  archive/logo-white-tile-2026-11-21.png  Superseded white-tile artwork, kept as a record.
  archive/neon-emblem-2026-07-25-<size>.* Retired mark, kept for old posts and documents.

FAVICONS (included in current/)

  /brand/favicon-128.png
  /brand/favicon-64.png
  /brand/favicon-32.png
  /brand/favicon-16.png
  /brand/apple-touch-icon.png

USAGE

Use the mark to refer to Next Step Studios in editorial work. Do not alter,
recolour, stretch, rotate or crop it, and do not add effects. Leave clear space
of at least one quarter of the mark's height on every side. Do not use it to
imply endorsement, partnership or sponsorship.

The full rules are at /press#guidelines. Retired marks are never overwritten or
deleted; they live at /press#archive with the retirement date in the filename.
The old /brand and /archive addresses redirect there.

HOW THIS KIT IS BUILT

This ZIP is generated from the website repository; editing the ZIP by hand only
lasts until the next build. To change it:

  npm run brand       rebuild every logo size and the ZIP from the artwork
  npm run brand:zip   rebuild only the ZIP from the files already in the repo

The folder comes from the file's home in the repository: public/brand/press
ships as current/, public/brand/archive ships as archive/. The favicons and the
white-tile edition are added from src/data/brand-assets.json and
public/brand/archive. The step-by-step
instructions are in README.md, under "The brand kit ZIP".
