Next Step Studios — brand kit
Generated 2026-11-21

WHAT IS IN HERE

  Current logo
    8 PNG, 4 JPG, 8 SVG
    Transparent master cut from the original white-tile artwork. The light outline treatment is for dark surfaces, where the black ninja would otherwise disappear.

  Retired neon orbit emblem
    4 PNG, 4 JPG, 4 SVG
    Retired 25 July 2026. Kept at stable addresses because older posts and documents still use it.

Every mark is supplied at 1024, 512, 256, 128 pixels, as:

  .png   Transparent. This is the file to use when the background is not known.
  .svg   An SVG wrapper around the transparent PNG at that size. It scales in
         layout without a blurry browser resize, but it is not a vector redraw
         of the artwork.
  .jpg   Flattened on the studio's dark base #07080B. JPG cannot store
         transparency, so these use the light-outline treatment: the black
         ninja and the black "STUDIOS" line would otherwise disappear.

The current mark also ships a "light" PNG and SVG for the same reason: on a
near-black surface the standard transparent mark loses its black areas. Use the
light treatment on dark, the standard transparent files on light.

WHICH FILE IS WHICH

  logo-<size>.png / .svg          Current logo, transparent, standard treatment.
  logo-<size>.jpg                 Current logo on #07080B, light outline.
  logo-light-<size>.png / .svg    Current logo, transparent, light outline.
  neon-emblem-2026-07-25-<size>.* Retired mark, kept for old posts and documents.

FAVICONS (in the site, not repeated in this ZIP's logo folders)

  /brand/favicon-128.png
  /brand/favicon-64.png
  /brand/favicon-32.png
  /brand/apple-touch-icon.png

USAGE

Use the mark to refer to Next Step Studios in editorial work. Do not alter,
recolour, stretch, rotate or crop it, and do not add effects. Leave clear space
of at least one quarter of the mark's height on every side. Do not use it to
imply endorsement, partnership or sponsorship.

The full rules are at /brand. Retired marks are never overwritten or deleted;
they live at /archive with the retirement date in the filename.
