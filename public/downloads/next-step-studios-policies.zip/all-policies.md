<!--
  Next Step Studios — complete public document set

  11 documents across the Discord bot and website sets,
  all at the versions listed in each section.
  This is an offline copy. The versions published on the website are
  authoritative, and this file may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Next Step Studios — Policies

11 public documents in two separate scopes. Drafts and current
documents are labelled individually.

## Contents

1. [Discord bot] Discord Bot Terms of Service — v0.2.0
2. [Discord bot] Discord Bot Privacy Policy — v0.2.0
3. [Discord bot] Discord Bot Acceptable Use Policy — v0.2.0
4. [Discord bot] Discord Bot Community Guidelines — v0.2.0
5. [Discord bot] Discord Bot Moderation and Enforcement Policy — v0.2.0
6. [Discord bot] Discord Bot Data Retention and Deletion Policy — v0.2.0
7. [Discord bot] Discord Bot Security and Data Protection Overview — v0.2.0
8. [Website] Website Privacy Notice — v1.0.0
9. [Website] Website Terms of Use — v0.1.0
10. [Website] Website Copyright and Takedown Notice — v0.1.0
11. [Website] Website Security Overview — v1.0.0

---

<!--
  Discord Bot Terms of Service
  Next Step Studios - Discord bot documentation

  Version:    0.2.0
  Status:     Draft for review. Not yet effective.
  Applies to: The Next Step Studios Discord bot operating in the single private Next Step Studios Discord server

  Downloaded from: /policies/bot/terms

  This document is a draft for review and is not yet effective.

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Discord Bot Terms of Service

> The terms governing use of the Next Step Studios Discord bot.

**Plain-language summary:** These terms cover use of the bot in the studio's one private Discord server. The bot is not offered as a public or commercial service for other servers. The document sets out permitted use, the operator's role and what happens when the rules are broken.

**Version 0.2.0** · Draft for review. Not yet effective. · Applies to: The Next Step Studios Discord bot operating in the single private Next Step Studios Discord server

## 1. Introduction

### 1.1 About these Terms

These Terms of Service (the **"Terms"**) govern your access to and use of the Discord bot operated by Candler Shaw under the public-facing name **Next Step Studios** (the **"Studio," "Operator," "we," "us,"** or **"our"**).

The bot (the **"Bot"**) is intended to operate exclusively within one private Discord server associated with Next Step Studios (the **"Server"**). It is not currently offered as a public bot, commercial bot, or installation service for unrelated Discord servers.

The Bot is intended to support community and server operations. Depending on its implementation and configuration, its functionality may include:

- Staff and other applications.
    
- Application review and staff-related records.
    
- Support requests and ticket workflows.
    
- Announcements and announcement history.
    
- Suggestions and related review workflows.
    
- Server administration and configuration.
    
- Moderation-related tools and records.
    
- Ban appeals and appeal review workflows.
    
- Administrative logging and other operational features.
    

Not every feature described in these Terms is necessarily available or fully operational. A feature's actual availability depends on its implementation, testing, configuration, permissions, and deployment status.

### 1.2 Agreement to these Terms

By interacting with the Bot or submitting information through one of its features, you acknowledge that these Terms apply to your use of the Bot.

Where applicable law requires affirmative consent, additional notice, or a particular acceptance process, the Operator will use an appropriate process before treating these Terms as accepted.

If you do not agree with these Terms, do not use the Bot or submit information through its features.

Your use of Discord and your membership in the Server are also governed by Discord's own terms, policies, and rules. These Terms do not replace those requirements.

### 1.3 Scope and exclusions

These Terms apply only to:

- The Bot.
    
- Commands, buttons, modals, menus, and other interactions provided by the Bot.
    
- Bot-operated application, ticket, announcement, suggestion, moderation, appeal, and administrative workflows.
    
- Information submitted to or processed by the Bot in connection with those workflows.
    

These Terms do **not** currently govern:

- A Next Step Studios website.
    
- Website accounts, contact forms, analytics, or cookies.
    
- Video games, software utilities, or other products that may be developed in the future.
    
- Third-party services that are not operated by the Bot.
    
- Discord itself or services independently operated by Discord.
    

Any future service will require its own applicable terms and privacy disclosures, or a clearly identified revision to the relevant documents. The existence of these Bot Terms does not automatically extend them to unrelated services.

### 1.4 Relationship with Discord

The Bot operates through Discord's platform and may rely on Discord-provided information, permissions, APIs, and infrastructure.

You must comply with all applicable Discord requirements, including Discord's Terms of Service, Community Guidelines, Developer Terms of Service, Developer Policy, and other applicable policies.

The Operator does not control Discord's platform, availability, account systems, moderation decisions, data practices, or infrastructure. Discord remains responsible for the services it independently provides.

If Discord changes its platform, permissions, APIs, policies, or technical requirements, the Bot's functionality may need to change or may become temporarily or permanently unavailable.

---

## 2. Definitions

For purposes of these Terms:

- **"Bot"** means the Next Step Studios Discord application, including its commands, interactions, interfaces, and associated Bot-operated workflows.
    
- **"Server"** means the single private Next Step Studios Discord server in which the Bot is authorized to operate.
    
- **"Operator"** means Candler Shaw, operating under the public-facing name Next Step Studios.
    
- **"User"** means an individual who interacts with the Bot or whose information is processed through a Bot-operated feature.
    
- **"Authorized Personnel"** means the Operator and any other individual specifically authorized to access a relevant administrative function, system, or record.
    
- **"User Content"** means information submitted, uploaded, entered, or otherwise provided by a User through the Bot. This may include application answers, ticket messages, suggestions, appeal materials, support requests, and attachments.
    
- **"Bot Data"** means information received, generated, processed, or stored by the Bot in connection with its operation.
    
- **"Personal Information"** means information relating to an identifiable individual, as defined by applicable law.
    
- **"Application"** means a form or submission used to apply for a role, staff position, opportunity, or other Server-related status.
    
- **"Ticket"** means a Bot-operated support or communication workflow.
    
- **"Moderation Action"** means an action taken to address an alleged or established violation of Server rules or applicable policies.
    
- **"Appeal"** means a request for review of an eligible moderation decision.
    
- **"Policies"** means the applicable Next Step Studios Bot policies, including the Privacy Policy, Acceptable Use Policy, Community Guidelines, Moderation and Enforcement Policy, Data Retention and Deletion Policy, and Security and Data Protection Overview.
    
- **"Feature"** means an individual function or workflow provided by the Bot.
    

These definitions apply whether a Feature is accessed through a slash command, button, modal, menu, message, or another Bot-supported interface.

---

## 3. Eligibility and Discord Account Responsibility

### 3.1 Discord account

You must have a Discord account that is permitted to use Discord and the Server under Discord's applicable requirements.

The Operator does not create, manage, or authenticate your Discord account. You are responsible for maintaining control of your account and protecting your account credentials.

### 3.2 Account identity

The Bot may receive or process Discord-provided identifiers and account-related information to identify interactions, associate submissions with the correct User, enforce permissions, and maintain operational records.

You must not impersonate another individual, misrepresent your identity, or deliberately submit another person's identifying information as your own.

### 3.3 Minors and sensitive submissions

Do not submit information that a Bot Feature does not reasonably require.

In particular, do not submit passwords, authentication codes, payment-card information, government identification numbers, or highly sensitive personal information unless a specific, legitimate process has expressly requested it and the Operator has provided appropriate instructions.

The Bot is not intended to be a secure channel for transmitting highly sensitive information.

If you are unsure whether information is appropriate to submit, contact the Operator before submitting it.

---

## 4. Permitted Use

You may use the Bot only for its intended Server-related purposes and in accordance with:

1. These Terms.
    
2. The applicable Next Step Studios policies.
    
3. The Server's rules and instructions.
    
4. Discord's applicable terms and policies.
    
5. Applicable law.
    

Permitted activities may include:

- Submitting a legitimate staff or other application.
    
- Responding truthfully to application questions.
    
- Opening a ticket for a genuine support or administrative concern.
    
- Submitting a suggestion through an available workflow.
    
- Reading announcements and other Bot-published information.
    
- Using an available appeal process when eligible.
    
- Interacting with administrative Features for which you have permission.
    
- Providing information reasonably necessary for a Bot Feature to function.
    

Permission to use one Feature does not automatically grant permission to use administrative, staff-only, or restricted Features.

---

## 5. Prohibited Use

You must not use the Bot to:

- Harass, threaten, intimidate, exploit, or target another person.
    
- Submit knowingly false, deceptive, fraudulent, or materially misleading information.
    
- Impersonate another User, staff member, or the Operator.
    
- Submit applications, tickets, suggestions, or appeals for the purpose of disrupting operations.
    
- Spam commands, repeatedly create unnecessary submissions, or deliberately overload a Feature.
    
- Attempt to bypass cooldowns, restrictions, permissions, or access controls.
    
- Access, modify, delete, or interfere with records that you are not authorized to access.
    
- Exploit software vulnerabilities or intentionally trigger errors to disrupt the Bot.
    
- Attempt to obtain another User's private submissions or records without authorization.
    
- Upload malicious files, harmful code, or content intended to compromise systems or devices.
    
- Use the Bot to distribute scams, phishing attempts, malware, or unauthorized promotions.
    
- Circumvent moderation decisions through alternate accounts or other deceptive methods.
    
- Interfere with the Bot's operation, hosting environment, database, configuration, or infrastructure.
    
- Use the Bot in a way that violates Discord's policies or applicable law.
    

This list is not exhaustive. Conduct that undermines the Bot's intended operation, the security of its records, or the safety of the Server may also be restricted.

The Acceptable Use Policy provides additional detail about permitted and prohibited use.

---

## 6. Applications and Submitted Information

### 6.1 Accurate submissions

When submitting an application or other formal response, you are responsible for providing information that is truthful and accurate to the best of your knowledge.

You must not deliberately provide fabricated qualifications, false experience, misleading availability, or information intended to manipulate a review decision.

### 6.2 Review process

Applications may be reviewed by the Operator or other individuals authorized to participate in the relevant review process.

Submitting an application does not guarantee:

- Acceptance.
    
- Appointment to a staff position.
    
- A particular role or permission.
    
- A response within a particular timeframe.
    
- A particular review outcome.
    

The Operator may accept, decline, defer, request clarification, or close an application, subject to applicable law and the relevant policies.

### 6.3 Application records

Information submitted through an application Feature may be processed or stored for review, administration, recordkeeping, and related purposes.

The current understanding is that application answers and staff-related information are stored in a local database during testing. The precise production storage arrangement and retention schedule must be verified and documented before final publication of the applicable Privacy Policy and Data Retention and Deletion Policy.

### 6.4 No guarantee of confidentiality from all reviewers

Application information is not intended to be public merely because it is submitted through the Bot. However, it may be accessible to the Operator and any Authorized Personnel who require access for the relevant review or administrative purpose.

Do not assume that every submission is visible only to you and the Bot.

---

## 7. Tickets and Support Requests

### 7.1 Appropriate use

Tickets are intended for legitimate support, questions, reports, and other Server-related matters.

You must not use tickets to harass staff, submit knowingly false reports, repeatedly reopen resolved matters without a legitimate reason, or distribute unrelated material.

### 7.2 Ticket contents

Information submitted through a ticket may be visible to the individuals authorized to handle that ticket.

Depending on the implemented workflow, ticket information may include messages, attachments, identifying information, staff responses, timestamps, and related administrative details.

### 7.3 Transcripts and storage

The ticket Feature exists, but the precise behavior for transcript generation, transmission, and long-term persistence has not been fully verified.

Accordingly, these Terms do not promise that every ticket is permanently archived, that every ticket transcript is retained, or that a particular deletion process is already operational.

The Operator must verify the actual ticket workflow and update the applicable Privacy Policy and Data Retention and Deletion Policy before making definitive production commitments about ticket storage.

### 7.4 Sensitive information

Do not use tickets to send passwords, authentication codes, payment credentials, or other highly sensitive information unless the Operator has expressly established a suitable process for receiving it.

---

## 8. Suggestions and Community Feedback

Where a suggestion Feature is available, you may submit constructive ideas relating to the Server or its operation.

You must not use the suggestion Feature to:

- Harass or target individuals.
    
- Submit spam or duplicate submissions intended to disrupt review.
    
- Publish another person's private information.
    
- Submit unlawful or harmful material.
    
- Misrepresent another person's views or actions.
    

Suggestions may be reviewed, accepted, declined, deferred, or closed. Submission does not guarantee implementation.

The Bot may maintain suggestion records or publication history for administrative purposes, depending on the Feature's actual configuration and implementation.

Where a cleanup or deletion function is available, it must be used only by individuals with the required permissions and in accordance with the applicable safeguards.

---

## 9. Moderation and Enforcement

### 9.1 General authority

The Operator may take reasonable action to protect the Server, its Users, its records, and the proper operation of the Bot.

Depending on the applicable rules, circumstances, permissions, and available functionality, enforcement may include:

- A reminder or informal warning.
    
- A formal warning.
    
- Removal of content or restriction of a submission.
    
- Temporary restrictions on access to a Feature.
    
- A timeout or other Discord-supported restriction.
    
- Removal from the Server.
    
- A temporary or permanent ban from the Server.
    
- Other proportionate administrative measures.
    

The availability and use of these measures are governed by the Moderation and Enforcement Policy and the actual permissions and capabilities of Discord and the Bot.

### 9.2 No automatic guarantee of a particular outcome

The Operator may consider the seriousness of the conduct, context, impact, prior relevant history, intent, available evidence, and risk of further harm.

The same type of conduct may result in different outcomes where the surrounding circumstances materially differ.

These Terms do not create a guaranteed warning sequence or require the Operator to use every lesser measure before taking a more serious action.

### 9.3 Appeals

An appeal process may be provided for eligible moderation decisions.

An appeal is a request for review, not a guarantee that the original decision will be reversed, reduced, or reconsidered within a particular timeframe.

The Ban Appeal Feature is planned and must not be treated as operational until it has been implemented and verified. Any appeal process that becomes available will be governed by the applicable appeal instructions and Moderation and Enforcement Policy.

### 9.4 Separate Discord enforcement

The Operator's Server-level decisions do not control Discord's independent enforcement decisions. Discord may take action under its own policies regardless of whether the Operator has taken action.

---

## 10. Bot Availability and Changes

### 10.1 Availability

The Bot is provided on an availability-permitting basis. The Operator does not guarantee uninterrupted, error-free, or continuous operation.

The Bot may become unavailable because of:

- Local hosting or computer availability.
    
- Internet connectivity issues.
    
- Discord outages or platform changes.
    
- API limits or permission changes.
    
- Software defects.
    
- Database or storage problems.
    
- Maintenance, updates, or configuration changes.
    
- Security concerns or other circumstances beyond the Operator's reasonable control.
    

The Bot is currently being tested on the Operator's own computer. Its hosting arrangement may change as development progresses.

### 10.2 Feature changes

The Operator may add, modify, suspend, restrict, or discontinue a Feature.

A Feature may be changed where necessary for maintenance, security, reliability, policy compliance, or operational reasons.

The Operator will make reasonable efforts to avoid unnecessary disruption, but does not guarantee advance notice for every change, particularly where immediate action is necessary to protect the Bot or its data.

### 10.3 Development status

The Bot is a developing software project. Features may be incomplete, experimental, partially implemented, or subject to change.

You should not rely on an unverified Feature as the sole means of submitting an urgent report, preserving important information, or obtaining assistance.

If a critical submission appears to fail, use an available alternative Server contact method rather than repeatedly submitting the same information without confirmation.

---

## 11. Data and Privacy

### 11.1 Privacy Policy

The Privacy Policy explains what information the Bot may process, why it is processed, how it may be stored, who may access it, and how privacy requests may be submitted.

You should read the Privacy Policy before submitting information through the Bot.

### 11.2 Information processed

Depending on the Feature and its implementation, the Bot may process:

- Discord User IDs.
    
- Discord Server IDs.
    
- Usernames or display names where available or needed.
    
- Feature interaction information.
    
- Application answers and staff-related information.
    
- Ticket and support information.
    
- Suggestions and related review information.
    
- Announcement drafts or publication records.
    
- Administrative and moderation-related information where implemented.
    
- Technical and error information generated during operation.
    

This list describes categories that may be processed. It does not mean every category is collected or stored by every Feature.

### 11.3 Data handling limitations

The Operator will describe actual data practices in the Privacy Policy and Data Retention and Deletion Policy.

No statement in these Terms should be interpreted as a guarantee that a particular security control, encryption method, backup process, retention period, or automated deletion mechanism is in place unless that control has been implemented and verified.

### 11.4 Privacy requests

Questions or requests concerning personal information may be sent to:

[**nextstepstudiosofficial.contact@gmail.com**](mailto:nextstepstudiosofficial.contact@gmail.com)

The Privacy Policy explains what information to include and how to locate your Discord User ID.

A request is not automatically completed merely because an email is sent. The Operator may need to verify the requester's identity, identify the relevant records, assess applicable obligations, and respond through an appropriate process.

---

## 12. Intellectual Property and Submitted Content

### 12.1 Bot and Studio materials

To the extent owned or controlled by the Operator, the Bot's original code, branding, documentation, command structure, and other original materials remain the property of their respective rights holders.

These Terms do not transfer ownership of those materials to Users.

You may not claim ownership of the Bot or its original materials merely because you interact with it or submit information through it.

### 12.2 Your submitted content

You retain whatever rights you already hold in content you submit, subject to any rights held by other people and applicable law.

By submitting content through a Bot Feature, you authorize the Operator to receive, process, display to relevant reviewers, store where necessary, and use that content for the purpose of operating the relevant Feature and administering the Server.

This is a limited operational permission. It does not grant the Operator ownership of your submitted content.

### 12.3 Responsibility for submitted material

You are responsible for ensuring that you have the right to submit any content, files, or information you provide.

Do not submit material that infringes another person's rights, violates applicable law, or violates Discord's policies.

---

## 13. Third-Party Services

The Bot depends on Discord and may rely on other software, libraries, hosting components, or infrastructure to operate.

Third-party services are governed by their own terms and policies.

The Operator does not control third-party services and is not responsible for their independent availability, security, or data practices.

This section does not authorize the Operator to disclose User Content to unrelated third parties for advertising, sale, or unrelated purposes.

Any actual sharing or processing by an external service must be accurately described in the Privacy Policy.

---

## 14. Disclaimers

To the extent permitted by applicable law:

- The Bot is provided on an "as available" and "as is" basis.
    
- The Operator does not guarantee that every Feature will function without interruption or error.
    
- The Operator does not guarantee that every submission will be successfully delivered, stored, reviewed, or retained.
    
- The Operator does not guarantee a particular application, ticket, suggestion, moderation, or appeal outcome.
    
- The Operator does not guarantee that the Bot will be compatible with every Discord client, device, configuration, or future platform change.
    

Nothing in these Terms excludes a consumer right, statutory protection, or other legal protection that cannot lawfully be excluded.

---

## 15. Limitation of Liability

To the maximum extent permitted by applicable law, the Operator will not be liable for indirect, incidental, special, consequential, exemplary, or punitive damages arising from or relating to your use of, or inability to use, the Bot.

This may include loss of data, loss of opportunity, interruption of access, or reliance on an unavailable or malfunctioning Feature, where such exclusion is permitted by law.

Nothing in this section excludes or limits liability where applicable law does not permit that exclusion or limitation.

Nothing in these Terms limits rights or remedies that cannot lawfully be limited.

---

## 16. Suspension and Termination

### 16.1 User decision to stop using the Bot

You may stop interacting with the Bot at any time.

Stopping use of the Bot does not automatically delete records that were previously created or submitted. Data handling and deletion are governed by the Privacy Policy and Data Retention and Deletion Policy.

### 16.2 Restriction by the Operator

The Operator may restrict or suspend access to a Feature, or take other appropriate action, where reasonably necessary because of:

- A violation of these Terms or another applicable policy.
    
- Abuse, spam, or disruption.
    
- A security or operational concern.
    
- A requirement imposed by Discord.
    
- A legal obligation.
    
- A need to protect Users, the Server, or Bot records.
    

### 16.3 Discontinuation

The Operator may discontinue the Bot or an individual Feature.

Where reasonably practicable, the Operator will consider the effect on active workflows and records. Any continued retention or deletion of information will remain subject to the applicable privacy and retention requirements.

---

## 17. Changes to These Terms

The Operator may revise these Terms to reflect:

- Changes to the Bot's Features.
    
- Changes in data processing or storage.
    
- Changes to Discord's platform or applicable requirements.
    
- Security or operational improvements.
    
- Changes in applicable law.
    
- Corrections, clarifications, or improvements to the document.
    

The document version and revision date should be updated whenever a substantive revision is made.

Where a change materially affects Users' rights, responsibilities, or the way a Feature operates, the Operator should provide reasonable notice through an appropriate Server channel or Bot interaction where practicable.

The current version should be made available through an accessible Bot command, public policy document, or other clearly identified method.

Continued use after a revised version becomes effective may constitute acceptance where permitted by applicable law. Where affirmative acceptance is legally required, the Operator will obtain it through an appropriate process.

---

## 18. Governing Law and Disputes

These Terms are intended to be interpreted under applicable law.

Any governing-law or dispute-resolution provision must be reviewed and completed before these Terms are finalized. The Operator should not assume that a particular state-law clause, court-selection clause, arbitration requirement, or waiver is enforceable in every circumstance.

Nothing in these Terms prevents a User from exercising a legal right that cannot lawfully be waived or restricted.

Users are encouraged to raise ordinary questions or concerns with the Operator first using the contact information below. This does not prevent either party from pursuing rights or remedies available under applicable law.

---

## 19. Contact Information

For questions about these Terms, the Bot, or its operation, contact:

**Next Step Studios**  
**Operator:** Candler Shaw  
**Email:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

When contacting the Operator, describe the relevant Bot Feature and the issue as clearly as possible.

Do not include passwords, authentication codes, or unnecessary sensitive information in your message.

---

## 20. Related Policies

These Terms should be read alongside the following Bot policies:

1. **Privacy Policy**  
    Explains information processed by the Bot, its purposes, access, and privacy requests.
    
2. **Acceptable Use Policy**  
    Describes permitted and prohibited use of the Bot and its Features.
    
3. **Community Guidelines**  
    Describes expected conduct within the Server.
    
4. **Moderation and Enforcement Policy**  
    Explains how potential rule violations may be reviewed and addressed.
    
5. **Data Retention and Deletion Policy**  
    Explains how Bot records are intended to be retained, reviewed, and deleted.
    
6. **Security and Data Protection Overview**  
    Provides a public-facing explanation of the Operator's security and data-protection approach.
    

If two policies address the same subject, they should be interpreted consistently. If a genuine conflict cannot be resolved, the Operator should clarify the documents and publish a corrected version rather than relying on ambiguous wording.

---

## 21. Draft Status and Publication Notice

This document is a working draft prepared for review.

It is not a representation that every described Bot Feature is operational, that every security measure has been implemented, or that every legal provision has been reviewed by a qualified legal professional.

Before publication, the Operator should:

- Verify the Bot's actual Features and permissions.
    
- Confirm the actual data collected and stored by each Feature.
    
- Review the Privacy Policy and Data Retention and Deletion Policy for consistency.
    
- Confirm that the Bot provides an accessible way to view applicable policies.
    
- Confirm that any required privacy-request process is operational.
    
- Review the document for applicable legal requirements.
    
- Replace draft status with an effective date only after approval and publication.
    

**End of document.**

---

<!--
  Discord Bot Privacy Policy
  Next Step Studios - Discord bot documentation

  Version:    0.2.0
  Status:     Draft for review. Not yet effective.
  Applies to: The Next Step Studios Discord bot operating in the single private Next Step Studios Discord server

  Downloaded from: /policies/bot/privacy

  This document is a draft for review and is not yet effective.

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Discord Bot Privacy Policy

> What information the Discord bot processes and stores, and how to submit a privacy request.

**Plain-language summary:** The bot runs in one private Discord server. This policy lists the information it may process, why each record exists, who can access it, and how to ask for access, correction or deletion. It says information is not sold or used for advertising.

**Version 0.2.0** · Draft for review. Not yet effective. · Applies to: The Next Step Studios Discord bot operating in the single private Next Step Studios Discord server

## 1. Introduction

Next Step Studios ("Studio," "we," "us," or "our") respects the privacy of individuals who interact with its Discord bot (the "Bot").

This Privacy Policy explains what information the Bot may receive, process, generate, and store; why that information may be used; who may have access to it; how it is intended to be retained; and how you can submit a privacy-related request.

The Bot is operated by **Candler Shaw**, using the public-facing name **Next Step Studios**.

The Bot is intended to operate exclusively in one private Next Step Studios Discord server. It is not currently offered for installation or use in unrelated Discord servers.

### 1.1 Important distinction between current and planned functionality

The Bot is under development and testing. Some Features are operational, some are partially implemented, some require further verification, and others are planned but not yet implemented.

This Privacy Policy distinguishes between:

- Information the Bot is currently understood to process or store.
    
- Information a Feature may process when used.
    
- Information associated with a partially implemented or unverified workflow.
    
- Information that may be processed if a planned Feature is implemented in the future.
    

A description of a planned Feature is not a statement that the Feature currently collects or stores information.

The Operator must verify actual behavior before making a definitive claim about a Feature's production data practices.

### 1.2 Scope

This Policy applies only to information processed in connection with the Next Step Studios Discord Bot and its Bot-operated workflows.

It does not apply to:

- Discord's own account, platform, or data practices.
    
- A Next Step Studios website. No website is currently covered by this Policy.
    
- Other websites, applications, games, or software operated by third parties.
    
- Independent communications or records that are not processed through the Bot.
    
- Services operated by another person or organization.
    

Discord's own Privacy Policy and other applicable Discord notices govern Discord's independent processing of information.

---

## 2. Information We May Process

The information processed depends on the Feature you use, the information you submit, the permissions granted to the Bot, and the Bot's actual implementation.

The categories below describe the current understanding of the Bot's data practices. They should not be interpreted as a claim that every category is collected or stored in every interaction.

### 2.1 Discord account and server identifiers

The Bot uses Discord identifiers to recognize the relevant account, associate interactions with records, and operate within the intended Server.

These identifiers may include:

- **Discord User ID:** A unique identifier associated with a Discord account.
    
- **Discord Server ID:** An identifier for the Server in which the Bot operates.
    
- **Channel identifiers:** Where needed to direct or associate a Bot workflow with a particular channel.
    
- **Role identifiers:** Where needed to determine or manage permissions and role-based workflows.
    
- **Message or interaction identifiers:** Where needed to associate an action with a particular message or interaction.
    

The current known data practices include the use of Discord User IDs and the Server ID.

Other identifiers may be processed as required by individual Features. Their actual use and storage must be confirmed against the deployed code and configuration.

### 2.2 Usernames, display names, and profile information

Discord may make certain account-related information available to the Bot when a User interacts with it.

Depending on the interaction and Discord's API behavior, this may include:

- Discord username.
    
- Server nickname or display name.
    
- User avatar or other profile-related information exposed through the relevant interaction.
    
- Other limited information made available by Discord for the operation of the Feature.
    

The Operator has not fully verified whether usernames and display names are persistently stored in the Bot's database or only processed temporarily during interactions.

Accordingly, this Policy does not promise that these values are never stored, nor does it claim that they are permanently stored in every case. That behavior must be checked and documented before final publication.

### 2.3 Application answers and staff information

The Bot includes application-related functionality.

When you submit an application, the information you provide may include:

- Answers to application questions.
    
- Information relevant to the position or opportunity for which you apply.
    
- Your Discord User ID.
    
- Information associated with the application review process.
    
- Review outcomes, reviewer comments, or administrative information, where implemented.
    
- Information needed to associate an application with a staff record, where applicable.
    

The current understanding is that application answers and staff-related information are stored in a local database during testing.

Access is currently limited to the Operator. If additional authorized reviewers are given access in the future, this Policy and the relevant access controls must reflect that change.

Application information is used for application review, staff administration, and related Server operations. It is not intended to be publicly displayed merely because you submit an application.

### 2.4 Tickets and support requests

The Bot includes a ticket or support workflow.

Information submitted through a ticket may include:

- Messages you send through the ticket.
    
- Your Discord User ID.
    
- Relevant channel or ticket identifiers.
    
- Attachments or other content you choose to submit.
    
- Responses from authorized staff.
    
- Timestamps and workflow status information.
    
- Transcript or administrative information, if generated by the implemented workflow.
    

**Important implementation qualification:** The precise ticket transcript-generation, transmission, and long-term persistence behavior has not been fully verified.

The Operator must inspect the actual ticket implementation to establish:

1. Whether transcripts are automatically generated.
    
2. Whether transcripts are sent to a Discord channel, saved locally, or both.
    
3. Whether ticket messages are stored in a database.
    
4. Whether closed tickets remain accessible.
    
5. Whether attachments are copied or retained separately.
    
6. Which individuals can access ticket records.
    
7. How ticket records and transcripts are deleted.
    

Until those checks are complete, this Policy does not make a definitive promise about the exact storage or deletion behavior of ticket conversations.

Do not submit passwords, authentication codes, payment information, or unnecessary sensitive information through a ticket.

### 2.5 Suggestions and feedback

Where the suggestion Feature is used, the Bot may process:

- The suggestion text.
    
- Your Discord User ID.
    
- Submission identifiers.
    
- Submission status.
    
- Review or administrative information.
    
- Publication information, where applicable.
    

The suggestion system may use temporary JSON files for certain workflow information. Announcement and publication history is intended to use SQLite, but the exact implementation state must be verified.

The Bot's suggestion and announcement workflows must be reviewed separately to establish exactly which information is temporary and which information becomes a persistent record.

### 2.6 Announcements and publication records

The Bot includes announcement-related functionality.

Depending on the workflow, information may include:

- Announcement drafts.
    
- Announcement text.
    
- The identity of the person who prepared or approved an announcement.
    
- Publication status.
    
- Publication timestamps.
    
- The Discord message or channel associated with a published announcement.
    
- Administrative history relating to publication.
    

Some announcement workflow information is understood to use temporary JSON storage. Announcement history is intended to be stored in SQLite.

Temporary drafts should not become permanent records merely because they were created. The intended lifecycle and actual cleanup behavior must be verified before a fixed retention commitment is made.

### 2.7 Moderation and infraction information

Moderation and persistent infraction recordkeeping are planned capabilities.

If implemented, these Features may process information such as:

- The Discord User ID of the affected individual.
    
- The Discord User ID of the staff member responsible for an action.
    
- The type of action.
    
- The reason recorded for the action.
    
- Relevant evidence or supporting information.
    
- Dates and timestamps.
    
- Expiration or review information.
    
- Related moderation history.
    

The Bot's persistent moderation and infraction recordkeeping is not currently confirmed as operational.

This section describes potential future processing, not a claim that the Bot currently maintains a complete moderation database.

### 2.8 Ban appeals

A dedicated ban appeal workflow is planned and is not currently confirmed as operational.

If implemented, an appeal may contain:

- The appellant's Discord User ID.
    
- The moderation action being appealed.
    
- The explanation provided by the appellant.
    
- Supporting information or attachments.
    
- Review notes and decisions.
    
- Relevant timestamps and administrative status.
    

The exact appeal workflow, storage arrangement, access permissions, and retention schedule must be established before the Feature is enabled and before this section is treated as a description of active processing.

### 2.9 Technical and diagnostic information

The Bot may generate technical information necessary to operate, troubleshoot, and maintain its software.

This may include:

- Error messages.
    
- Exception details.
    
- Timestamps.
    
- Feature or command names.
    
- Workflow status.
    
- Information about failed operations.
    
- Limited diagnostic context.
    

Technical logs should not contain passwords, bot tokens, authentication secrets, or unnecessary copies of User Content.

The exact logging configuration and retention behavior must be reviewed. This Policy does not claim that a particular logging system or retention period is already in place.

### 2.10 Information you choose not to provide

Some Features may require particular information to function.

If you choose not to provide information required by a Feature, the Bot may be unable to accept or process your submission.

You should provide only information reasonably necessary for the Feature you are using. Do not include unrelated personal details merely because a form or text field permits additional content.

---

## 3. How We Use Information

Information processed by the Bot is used for legitimate Bot and Server operational purposes, including the following.

### 3.1 Operating the Bot

Information may be used to:

- Identify the Discord account interacting with the Bot.
    
- Associate an interaction with the correct User or Server.
    
- Determine whether a User or staff member has permission to use a Feature.
    
- Route submissions to the appropriate workflow.
    
- Maintain the Bot's configuration and operational state.
    
- Prevent duplicate or invalid operations where supported.
    

### 3.2 Application administration

Application information may be used to:

- Receive and organize applications.
    
- Allow authorized reviewers to evaluate submissions.
    
- Communicate application outcomes.
    
- Maintain staff-related information where appropriate.
    
- Support the administration of staff positions and responsibilities.
    

### 3.3 Support and ticket handling

Ticket information may be used to:

- Receive support requests.
    
- Allow authorized individuals to respond.
    
- Track the status of an issue.
    
- Preserve relevant information while a request is being handled.
    
- Maintain a record where the implemented workflow requires one.
    

### 3.4 Suggestions and announcements

Suggestion and announcement information may be used to:

- Receive community feedback.
    
- Review suggestions.
    
- Track decisions or statuses.
    
- Prepare and publish announcements.
    
- Maintain relevant publication history.
    
- Prevent accidental duplication or loss of workflow information.
    

### 3.5 Moderation and Server administration

If and when the relevant Features are implemented, information may be used to:

- Review reported conduct.
    
- Record moderation decisions.
    
- Associate actions with the relevant accounts.
    
- Maintain relevant administrative history.
    
- Review eligible appeals.
    
- Protect the Server and its Users.
    

### 3.6 Security, troubleshooting, and reliability

Technical and operational information may be used to:

- Diagnose errors.
    
- Investigate failed operations.
    
- Maintain the Bot.
    
- Identify misuse or attempted interference.
    
- Protect records and systems.
    
- Improve the reliability of implemented Features.
    

### 3.7 Legal and compliance purposes

Information may be retained or processed where reasonably necessary to:

- Respond to a valid legal request.
    
- Comply with applicable law.
    
- Protect legal rights.
    
- Investigate suspected abuse or security incidents.
    
- Preserve information where a lawful obligation requires it.
    

Any such retention must be limited to the applicable purpose and legal requirement.

---

## 4. How Information Is Stored

### 4.1 Current testing arrangement

The Bot is currently being tested on the Operator's own computer.

The current understanding is:

- Application answers and staff-related information are stored in a local database.
    
- Some temporary workflow information is stored in JSON files.
    
- Announcement history is intended to be stored in SQLite.
    
- The precise ticket transcript and persistence behavior has not been fully verified.
    
- Persistent moderation and ban appeal recordkeeping are planned rather than confirmed operational Features.
    

The production hosting arrangement may change in the future. Any material change to storage, hosting, access, or external processing must be reviewed and reflected in this Policy before the change is treated as an established data practice.

### 4.2 Local storage does not mean risk-free storage

A local database or local file is not automatically secure merely because it is stored on a computer controlled by the Operator.

Security depends on the actual device configuration, operating system, account permissions, storage protection, backups, physical access, and other safeguards.

The Operator must verify which safeguards are implemented rather than relying on assumptions.

### 4.3 Database and file formats

The Bot may use structured databases and temporary files to support its Features.

The current development arrangement includes SQLite and JSON-based storage for certain workflows.

These formats describe how information may be organized. They do not, by themselves, establish whether information is encrypted, backed up, automatically deleted, or accessible only to a particular person.

### 4.4 Encryption

The encryption-at-rest status of the Bot's local database and related stored files has not been confirmed for purposes of this draft.

This Policy therefore does not claim that every database, JSON file, transcript, backup, or other stored record is encrypted at rest.

Before production use, the Operator must verify the applicable storage-protection requirements and implement the necessary safeguards.

Information transmitted through Discord is also subject to Discord's own platform and infrastructure practices. The Operator does not independently control Discord's transport security or internal storage.

---

## 5. Who Can Access Information

### 5.1 Operator access

The current access arrangement is that the Operator, Candler Shaw, is authorized to review stored User information for relevant Bot administration, application review, troubleshooting, and other legitimate operational purposes.

The Bot is intended to restrict access to records according to the permissions and administrative roles required by each Feature.

### 5.2 Authorized reviewers and staff

Some information may need to be shown to an authorized reviewer or staff member to perform a specific Server responsibility.

For example:

- Application information may be shown to individuals responsible for application review.
    
- Ticket information may be shown to individuals responsible for handling the ticket.
    
- Moderation information may be shown to individuals authorized to review or administer moderation matters, if that Feature is implemented.
    

The current confirmed access arrangement is limited to the Operator. Any expansion of access must be deliberate, limited to legitimate responsibilities, and reflected in the Bot's permissions and documentation.

Being a Server member or staff member does not automatically entitle someone to access every stored record.

### 5.3 Discord

The Bot operates through Discord. Discord may independently process information under its own Privacy Policy, Terms of Service, and other applicable policies.

The Operator does not control Discord's independent processing.

### 5.4 External service providers

The current development and testing arrangement does not establish a complete, verified inventory of external service providers that may process Bot Data.

If the Bot is later moved to a hosting provider, database provider, logging service, backup service, or another external service, the Operator must assess what information that provider receives and update this Policy where required.

The Operator should not provide identifiable User submissions or private User records to an external provider unless there is a legitimate, documented reason and appropriate safeguards.

### 5.5 AI tools and development assistance

The Operator may use AI-assisted development tools to help write, review, troubleshoot, or improve the Bot's code and documentation.

Using an AI tool for software development does **not** automatically authorize sending identifiable User information, application answers, private ticket conversations, appeal materials, or other private submissions to that tool.

The Operator should use synthetic examples, redacted excerpts, or non-identifying technical information when requesting AI assistance.

Private User records must not be supplied to an AI service merely because the Operator uses that service to assist with development.

This Policy does not claim that an AI provider has access to the Bot's database or User submissions. Any future integration that actually sends Bot Data to an AI service must be separately assessed, documented, and disclosed before it is enabled.

### 5.6 No public disclosure by default

Private application answers, ticket conversations, and other non-public submissions are not intended to be made publicly available merely because they were submitted through the Bot.

Information may be displayed in a Server channel when a Feature is specifically designed to publish it, such as an approved announcement or public suggestion. The intended audience and publication behavior should be clear from the Feature.

---

## 6. Sale, Advertising, and Unrelated Use

The Operator does not intend to sell Bot Data or use private User submissions for unrelated advertising.

The Bot's information is intended to support its operation and the administration of the private Server.

The Operator does not authorize the use of private application answers, ticket conversations, appeal submissions, or other private User Content for unrelated marketing or advertising.

The Operator also does not authorize the use of private User Content to train an AI or machine-learning model merely because AI tools may be used to assist with software development.

This does not prevent the Operator from using non-identifying technical examples or synthetic data for development and troubleshooting.

---

## 7. Data Retention

### 7.1 General rule

Information should be retained only for as long as reasonably necessary for the purpose for which it was collected, subject to applicable legal obligations and legitimate operational requirements.

The Operator should not retain information indefinitely merely because storage is available or because preserving a complete history is convenient.

Retention should take account of:

- The type of information.
    
- The purpose for which it was collected.
    
- Whether the relevant Feature remains active.
    
- Whether the record is still needed for administration or review.
    
- The sensitivity of the information.
    
- Security risks associated with continued retention.
    
- Applicable legal obligations.
    

### 7.2 No fixed retention periods are currently promised

Specific retention periods have not yet been finalized for every category of Bot Data.

This Policy therefore does not promise that applications, tickets, transcripts, suggestions, logs, backups, or other records will be deleted after a particular number of days or months.

A documented retention schedule must be established and implemented before the Operator makes fixed deletion-time commitments.

### 7.3 Temporary information

Temporary drafts and workflow files should not become permanent records accidentally.

For example, announcement drafts and other temporary JSON-based workflow data should be removed when no longer needed, subject to any legitimate recovery or operational requirement.

The actual cleanup behavior must be verified against the deployed implementation.

### 7.4 Backups

The backup process and backup-retention schedule have not been fully confirmed.

If backups are implemented, the Operator must document:

- What information is backed up.
    
- Where backups are stored.
    
- Who can access them.
    
- How backups are protected.
    
- How long backups are retained.
    
- How deletion requests are handled in relation to backup copies.
    

Deleting a record from the live database may not immediately remove an older copy contained in a backup. A reliable backup-expiration or deletion process must be established and accurately described.

### 7.5 Further details

The Data Retention and Deletion Policy provides the detailed retention framework and identifies the implementation decisions that remain outstanding.

---

## 8. Data Sharing and Disclosure

The Operator does not intend to disclose Bot Data indiscriminately.

Information may be disclosed or made available only where reasonably necessary for the Bot's operation, the relevant Server workflow, or another legitimate and lawful purpose.

Potential circumstances include:

### 8.1 Authorized Server administration

Relevant information may be made available to the Operator or an authorized reviewer who needs it to perform a legitimate administrative responsibility.

### 8.2 Discord platform operation

Information is processed through Discord as part of the Bot's operation. Discord's own data practices apply to information Discord independently processes.

### 8.3 Service providers

If an external provider is used to host, store, back up, monitor, or maintain the Bot, the provider may process information necessary to provide that service.

The Operator must identify the provider, determine what information it receives, and update this Policy where appropriate before relying on that arrangement in production.

### 8.4 Legal obligations and protection

Information may be disclosed where the Operator reasonably believes disclosure is required by applicable law or a valid legal process, or is necessary to protect the rights, safety, or security of the Operator, the Server, or another individual.

Where legally permitted and reasonably practicable, disclosure should be limited to the information necessary for the relevant purpose.

### 8.5 No unrelated sale or disclosure

The Operator does not intend to sell Bot Data, rent private User submissions, or disclose private User Content for unrelated advertising.

---

## 9. Your Privacy Rights and Requests

You may contact the Operator with questions or requests concerning information associated with your use of the Bot.

Depending on applicable law and the circumstances, you may request:

- Information about whether the Bot holds records associated with you.
    
- Access to relevant information.
    
- Correction of inaccurate information.
    
- Deletion of information.
    
- Clarification about how a particular Feature processes information.
    
- Review of a concern about the handling of your information.
    

Not every request can necessarily be granted in full. For example, certain information may need to be retained where required by law, necessary for a legitimate and documented operational purpose, or needed to protect another person's rights.

The Operator will assess each request individually and explain any material limitation where appropriate.

### 9.1 How to submit a privacy request

Send your request to:

[**nextstepstudiosofficial.contact@gmail.com**](mailto:nextstepstudiosofficial.contact@gmail.com)

Use a subject line such as:

**Privacy Request - Next Step Studios Discord Bot**

In your message, include:

1. Your Discord User ID, if you can safely obtain it.
    
2. The Bot Feature involved, if known. For example, an application, ticket, suggestion, or another workflow.
    
3. A clear description of what you are requesting.
    
4. Any relevant date, approximate timeframe, or reference that may help identify the record.
    

You do not need to send your password, authentication code, recovery code, or other account credentials.

Do not send unrelated sensitive information.

### 9.2 Why your Discord User ID may be requested

A Discord User ID is a stable account identifier that can help distinguish your account from other accounts with similar usernames or display names.

Usernames and display names can change. A User ID is generally a more reliable way to identify the relevant account when locating Bot records.

Only provide your User ID through the privacy-request email address above. Do not post it publicly unless there is a clear reason to do so.

### 9.3 How to enable Developer Mode

If you do not know how to find your Discord User ID, Discord provides an official guide explaining how to enable Developer Mode.

**Official Discord guide: Enable Developer Mode**

[Discord: Where can I find my User/Server/Message ID?](https://support.discord.com/hc/en-us/articles/206346498-Where-can-I-find-my-User-Server-Message-ID)

If Developer Mode is already enabled on your Discord account, you can skip this step.

**On desktop:**

1. Open Discord.
    
2. Open User Settings using the gear icon.
    
3. Select **Advanced**.
    
4. Find **Developer Mode**.
    
5. Turn Developer Mode on.
    

**On mobile:**

1. Open Discord.
    
2. Tap your avatar.
    
3. Open User Settings using the gear icon.
    
4. Find **Advanced** under App Settings.
    
5. Turn Developer Mode on.
    

Discord may change the layout or wording of its settings. Follow the current instructions displayed in Discord's official guide if the menu looks different.

### 9.4 How to copy your Discord User ID

After Developer Mode is enabled, use Discord's official instructions to copy your User ID.

**Official Discord guide: Find and copy a User ID**

[Discord: Where can I find my User/Server/Message ID?](https://support.discord.com/hc/en-us/articles/206346498-Where-can-I-find-my-User-Server-Message-ID)

**On desktop:**

1. Find your account in the Server, a direct message, or another Discord location where your profile is visible.
    
2. Right-click your username or avatar.
    
3. Select **Copy User ID**.
    
4. Paste the copied ID into your privacy-request email.
    

**On mobile:**

1. Find your account in Discord.
    
2. Tap your profile or avatar.
    
3. Open the three-dot menu in the profile.
    
4. Select **Copy User ID**.
    
5. Paste the copied ID into your privacy-request email.
    

If the menu options differ, use the official Discord guide linked above.

### 9.5 What happens after you submit a request

A privacy request may require the Operator to:

1. Review the request.
    
2. Determine what information is needed to identify the relevant records.
    
3. Verify that the request is associated with the relevant Discord account.
    
4. Search the applicable database, files, or workflow records.
    
5. Determine whether the requested action can be completed.
    
6. Identify any applicable legal or operational reason that may limit deletion or modification.
    
7. Respond using the contact method provided.
    

The time required may depend on the complexity of the request and the state of the Bot's records.

This email process is the documented method for submitting a privacy request. It should not be interpreted as an automated deletion command or an assurance that a request is completed immediately upon receipt.

### 9.6 Verification and protection against unauthorized requests

The Operator may request reasonable additional information to verify that a privacy request concerns the correct account.

The Operator should not request passwords, authentication codes, recovery codes, or account tokens to verify a request.

A request may be delayed or declined if the Operator cannot reasonably establish which records are involved or whether the requester is authorized to make the request.

---

## 10. Security and Data Protection

The Operator takes the protection of Bot Data seriously and intends to use safeguards appropriate to the nature of the information and the Bot's operational environment.

However, the exact security configuration is still subject to implementation and verification.

### 10.1 Access restrictions

Access to stored information should be limited to the Operator and any specifically authorized individual who requires access for a legitimate responsibility.

Administrative access should not be granted merely because someone is a Server member or holds a general staff role.

### 10.2 Credentials and secrets

Bot tokens, passwords, API keys, and other authentication secrets must be protected and must not be included in public policy documents, logs, support messages, or ordinary User-facing records.

### 10.3 Storage protection

The Operator must verify the security of the local computer, database files, temporary files, and any backups.

The use of a local database does not automatically establish that the data is encrypted or protected against unauthorized access.

### 10.4 Security incidents

If the Operator becomes aware of a suspected or confirmed incident involving unauthorized access, disclosure, alteration, or loss of Bot Data, the Operator should investigate and take reasonable steps to contain and address it.

Where applicable law or Discord's requirements impose notification or reporting obligations, those obligations must be followed.

### 10.5 No guarantee of absolute security

No software system, storage device, network, or online service can be guaranteed to be completely secure.

The Operator will work to protect Bot Data, but cannot promise that unauthorized access, software defects, platform failures, or other security incidents will never occur.

The Security and Data Protection Overview provides additional public-facing information about the intended safeguards.

---

## 11. International Processing

The Bot is operated through Discord, a platform that may process information using infrastructure located in different jurisdictions.

The Operator's current testing arrangement uses local storage on the Operator's own computer. The exact locations and arrangements of any future hosting, backup, or external service providers have not been finalized in this draft.

If the Bot moves to external hosting or begins using additional providers, the Operator must assess the relevant processing locations and update this Policy where necessary.

Applicable privacy laws may provide different rights depending on where a User lives.

---

## 12. Children's Privacy

The Bot is intended for use by members of the private Server who are eligible to use Discord and the relevant Server Features under applicable rules.

The Operator does not intend to use the Bot to knowingly collect information from children in violation of applicable law or Discord's requirements.

Users should not submit unnecessary sensitive information about themselves or other individuals, including children.

If a parent, guardian, or other authorized individual believes that information has been submitted in a way that raises a privacy concern, they may contact the Operator at the email address listed in this Policy.

The Operator will review the concern and determine what action is appropriate under applicable law and the circumstances.

---

## 13. Changes to This Privacy Policy

This Policy may be updated when:

- The Bot gains or loses a Feature.
    
- A Feature begins collecting or storing a new category of information.
    
- The storage or hosting arrangement changes.
    
- New external service providers are introduced.
    
- Retention periods or deletion procedures are established or changed.
    
- Security controls are implemented or materially changed.
    
- Applicable legal requirements change.
    
- A correction or clarification is necessary.
    

A substantive update should include a new document version and revision date.

Where a change materially affects Users or the handling of their information, the Operator should provide reasonable notice through an appropriate Server channel or Bot interaction where practicable.

The current version should be made available through an accessible Bot command, public policy document, or other clearly identified method.

---

## 14. Contact Information

For privacy questions, data requests, or concerns about the Bot's handling of information, contact:

**Next Step Studios**  
**Operator:** Candler Shaw  
**Email:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

Please include enough information to identify the relevant Feature or record, but do not send passwords, authentication codes, or unnecessary sensitive information.

---

## 15. Related Policies

This Privacy Policy should be read alongside:

1. **Discord Bot Terms of Service**  
    Explains the terms governing use of the Bot.
    
2. **Acceptable Use Policy**  
    Explains permitted and prohibited use of the Bot and its Features.
    
3. **Community Guidelines**  
    Explains expected conduct within the Server.
    
4. **Moderation and Enforcement Policy**  
    Explains how potential violations may be reviewed and addressed.
    
5. **Data Retention and Deletion Policy**  
    Provides the detailed framework for retaining and deleting Bot records.
    
6. **Security and Data Protection Overview**  
    Provides public-facing information about the Operator's security approach.
    

---

## 16. Draft Status and Required Verification

This document is a working draft. It must not be presented as a final, legally reviewed Privacy Policy until the Operator has verified the actual implementation and approved the document.

Before publication, the Operator must complete the following checks:

### Data inventory

- Confirm every Discord identifier accessed by the Bot.
    
- Confirm whether usernames and display names are persistently stored.
    
- Identify every database and file used to store User information.
    
- Confirm what application information is stored and where.
    
- Confirm what staff information is stored and where.
    
- Inspect the ticket workflow and determine whether transcripts are generated.
    
- Determine whether ticket transcripts are sent to Discord channels, saved locally, or both.
    
- Determine whether ticket messages and attachments are stored separately.
    
- Confirm the actual storage and cleanup behavior of suggestion records.
    
- Confirm the actual storage and cleanup behavior of announcement drafts.
    
- Confirm whether announcement history is stored in SQLite.
    
- Identify any technical logs that may contain User information.
    
- Identify any backups and determine what they contain.
    

### Access and security

- Confirm which individuals can access each category of stored information.
    
- Confirm that permissions are limited to legitimate responsibilities.
    
- Verify how database files and temporary files are protected.
    
- Verify encryption-at-rest requirements and implementation.
    
- Review credential and secret handling.
    
- Identify any external hosting, storage, backup, or monitoring providers.
    
- Confirm whether any User Data is sent to external services.
    
- Confirm that private User submissions are not being sent to AI services as part of ordinary development assistance.
    

### Retention and deletion

- Establish a retention schedule for applications.
    
- Establish a retention schedule for staff records.
    
- Establish a retention schedule for tickets and transcripts.
    
- Establish a retention schedule for suggestions.
    
- Establish a retention schedule for announcement drafts and history.
    
- Establish a retention schedule for technical logs.
    
- Establish a retention schedule for backups.
    
- Define how deletion requests are handled across live databases, files, and backups.
    
- Verify that the documented deletion process can actually be carried out.
    

### User-facing process

- Confirm that the privacy-request email address is monitored.
    
- Establish a process for verifying privacy requests.
    
- Establish a process for searching and responding to requests.
    
- Make this Policy accessible to Server members.
    
- Provide an accessible way to request modification or deletion of personal information.
    
- Confirm that any Bot command described as a privacy-request feature actually exists before advertising it as functional.
    

**End of document.**

---

<!--
  Discord Bot Acceptable Use Policy
  Next Step Studios - Discord bot documentation

  Version:    0.2.0
  Status:     Draft for review. Not yet effective.
  Applies to: The Next Step Studios Discord bot operating in the single private Next Step Studios Discord server

  Downloaded from: /policies/bot/acceptable-use

  This document is a draft for review and is not yet effective.

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Discord Bot Acceptable Use Policy

> What is and is not permitted when using the Discord bot.

**Plain-language summary:** Use the bot for the private server's community and administrative work, not to abuse, disrupt or break Discord's rules. The policy names prohibited behaviour and explains that access can be limited when someone misuses the bot.

**Version 0.2.0** · Draft for review. Not yet effective. · Applies to: The Next Step Studios Discord bot operating in the single private Next Step Studios Discord server

## 1. Purpose

This Acceptable Use Policy (the **"Policy"**) establishes the rules governing how individuals may interact with and use the Next Step Studios Discord bot (the **"Bot"**).

The Bot is operated by Candler Shaw under the public-facing name **Next Step Studios** (the **"Studio"** or **"Operator"**).

The Bot is intended exclusively for use within one private Next Step Studios Discord server (the **"Server"**). It is designed to support Server administration and community workflows, which may include applications, staff administration, tickets, suggestions, announcements, moderation-related tools, appeals, and other administrative functions.

Not every Feature described in this Policy is currently implemented or available. Some are partially implemented, subject to verification, or planned for future development.

This Policy explains what Users may and may not do when interacting with the Bot. It supplements, but does not replace:

- The Discord Bot Terms of Service.
    
- The Privacy Policy.
    
- The Community Guidelines.
    
- The Moderation and Enforcement Policy.
    
- The Data Retention and Deletion Policy.
    
- Discord's own terms, policies, and rules.
    

---

## 2. Scope

This Policy applies to anyone who interacts with the Bot or submits information through a Bot-operated workflow.

It covers use of:

- Commands and slash commands.
    
- Buttons, menus, modals, and other interactive components.
    
- Application forms and application-review workflows.
    
- Staff-related administrative functions.
    
- Ticket and support workflows.
    
- Suggestion submissions and review functions.
    
- Announcement creation and publication functions.
    
- Moderation-related Features, where implemented.
    
- Appeal workflows, when implemented.
    
- Other Bot-operated administrative or community functions.
    

This Policy does not govern Discord's independent services or unrelated websites, applications, games, or software.

---

## 3. General Acceptable Use Principles

All Users must use the Bot in a way that is lawful, honest, reasonable, and consistent with its intended purpose.

You are expected to:

1. Use each Feature only for its intended purpose.
    
2. Provide accurate information when submitting a formal request or application.
    
3. Respect the privacy of other Users.
    
4. Avoid unnecessary or excessive submissions.
    
5. Follow the instructions presented by the Bot.
    
6. Respect access restrictions and permission requirements.
    
7. Avoid interfering with the Bot's operation.
    
8. Use support and administrative workflows responsibly.
    
9. Follow Discord's applicable requirements.
    
10. Cooperate with reasonable administrative instructions relating to Bot operation.
    

Permission to access one command or Feature does not give you permission to access another Feature or another person's records.

---

## 4. Applications and Formal Submissions

### 4.1 Truthful information

Applications and other formal submissions must contain information that is truthful and accurate to the best of your knowledge.

You must not:

- Invent qualifications, experience, or references.
    
- Deliberately misrepresent your availability or capabilities.
    
- Submit answers copied from another person while claiming they are your own.
    
- Use false information to obtain a staff position or privilege.
    
- Deliberately conceal information that a form specifically and legitimately requires.
    
- Impersonate another applicant.
    

### 4.2 Relevant information only

Provide information that is reasonably relevant to the questions being asked.

Do not include:

- Passwords.
    
- Authentication codes.
    
- Recovery codes.
    
- Payment-card information.
    
- Government identification numbers.
    
- Unnecessary personal information about yourself.
    
- Private information about another individual without a legitimate reason and authorization.
    

### 4.3 Repeated submissions

Do not repeatedly submit the same application or formal request to bypass a review process, create duplicate records, or pressure reviewers.

If you believe a submission failed, check whether it was received before submitting it again. If you cannot determine its status, use an available support method.

### 4.4 Review integrity

Do not attempt to manipulate an application review by:

- Threatening or harassing reviewers.
    
- Offering improper incentives.
    
- Coordinating dishonest responses.
    
- Submitting fabricated evidence.
    
- Using alternate accounts to create misleading impressions.
    
- Attempting to access another applicant's submission.
    

The Operator may reject or restrict submissions that undermine the integrity of the review process.

---

## 5. Tickets and Support Features

### 5.1 Intended purpose

Tickets are intended for legitimate support requests, questions, reports, and other Server-related matters.

Use the ticket system for issues that reasonably require assistance from the Operator or authorized staff.

### 5.2 Prohibited ticket behavior

You must not:

- Open tickets solely to spam or disrupt staff.
    
- Repeatedly open duplicate tickets without a legitimate reason.
    
- Harass, threaten, or insult staff members.
    
- Use tickets to target another User.
    
- Submit knowingly false reports.
    
- Use a ticket to distribute scams, malicious files, or harmful links.
    
- Attempt to obtain private information about another User without authorization.
    
- Deliberately exploit ticket creation, closure, or transcript functions.
    
- Use a ticket to evade a moderation restriction.
    

### 5.3 Appropriate information

Provide enough information for staff to understand the issue.

Avoid sending passwords, authentication codes, payment details, or unnecessary sensitive information.

If a report involves another User, include relevant facts and evidence where appropriate. Do not fabricate evidence or alter material to mislead reviewers.

### 5.4 Ticket privacy

A ticket should not be assumed to be visible only to the person who opened it and the Bot.

Ticket information may be accessible to the Operator and individuals authorized to handle the ticket. The exact transcript and storage behavior is still subject to implementation verification.

---

## 6. Suggestions and Feedback

Where available, the suggestion Feature is intended for constructive feedback and ideas relating to the Server or its operation.

You must not use it to:

- Submit spam.
    
- Repeatedly post substantially identical suggestions to manipulate visibility.
    
- Harass or target another User.
    
- Publish private or identifying information about another person.
    
- Submit threats or unlawful material.
    
- Impersonate another User.
    
- Deliberately disrupt the review process.
    
- Attempt to manipulate suggestion status or administrative records without permission.
    

Suggestions may be accepted, declined, deferred, closed, or otherwise reviewed. Submitting a suggestion does not guarantee implementation.

If a suggestion is already under review, use the existing submission or an appropriate support method rather than creating repeated duplicates.

---

## 7. Announcements and Publication Features

Announcement Features are intended for authorized individuals to prepare, review, and publish Server announcements.

If you are not authorized to create or publish announcements, you must not attempt to access or use those administrative functions.

Authorized Users must:

- Use announcement tools for legitimate Server communications.
    
- Check content for accuracy before publication.
    
- Avoid publishing private User information without authorization.
    
- Avoid publishing misleading or deliberately harmful announcements.
    
- Follow any approval process configured for the Feature.
    
- Avoid repeatedly triggering publication actions.
    
- Avoid attempting to bypass publication permissions.
    

Do not attempt to manipulate announcement history, publication records, or temporary drafts.

---

## 8. Moderation and Administrative Features

Moderation and other administrative functions may be restricted to the Operator or individuals specifically authorized to use them.

You must not:

- Attempt to execute moderation actions without permission.
    
- Access moderation records that are not available to you.
    
- Modify or delete administrative records without authorization.
    
- Impersonate a moderator or administrator.
    
- Use administrative commands to harass or retaliate against another User.
    
- Fabricate moderation evidence.
    
- Interfere with an investigation or review.
    
- Attempt to bypass a restriction imposed by the Operator.
    
- Exploit a software error to obtain administrative access.
    

The existence of a command name, button, or interface does not mean you are authorized to use it.

The Bot's persistent moderation and infraction recordkeeping is planned and must not be treated as a fully operational Feature until verified.

---

## 9. Appeals and Review Requests

If an appeal Feature becomes available, it must be used only for a genuine request to review an eligible moderation decision.

You must not:

- Submit knowingly false information.
    
- Fabricate evidence.
    
- Impersonate the affected User.
    
- Submit an appeal on another person's behalf without authorization.
    
- Use appeals to harass or threaten reviewers.
    
- Repeatedly submit duplicate appeals to pressure staff.
    
- Attempt to manipulate the review process.
    
- Use an appeal to distribute unrelated material.
    

An appeal does not guarantee that a decision will be reversed or reduced.

The dedicated ban appeal workflow is planned and is not currently confirmed as operational. Any future appeal Feature will be subject to its published instructions and the Moderation and Enforcement Policy.

---

## 10. Spam, Automation, and Excessive Use

You must not use the Bot in a manner that disrupts its normal operation or imposes unreasonable demands on its resources.

Prohibited behavior includes:

- Repeatedly invoking commands without a legitimate purpose.
    
- Creating excessive tickets, applications, or suggestions.
    
- Repeatedly clicking buttons or submitting forms to trigger duplicate actions.
    
- Attempting to bypass cooldowns or rate limits.
    
- Using scripts, macros, or automated accounts to abuse Bot Features.
    
- Deliberately generating excessive errors.
    
- Sending malformed or abusive input to disrupt processing.
    
- Attempting to exhaust storage, database capacity, or other resources.
    

This Policy does not prohibit ordinary accessibility tools or reasonable assistive technology. The concern is abusive or disruptive use, not legitimate accommodation.

---

## 11. Security and Technical Restrictions

You must not attempt to compromise, interfere with, or gain unauthorized access to the Bot or its supporting systems.

Prohibited activities include:

- Attempting to obtain the Bot's token, passwords, API keys, or other secrets.
    
- Attempting to access the Operator's computer or local storage.
    
- Attempting to access the Bot's database or internal files.
    
- Exploiting a vulnerability to access restricted information.
    
- Attempting SQL injection, command injection, or other malicious input attacks.
    
- Uploading malware or harmful files through a Bot Feature.
    
- Attempting to crash, disable, or overload the Bot.
    
- Interfering with database integrity.
    
- Tampering with configuration or operational files.
    
- Circumventing authentication or permission checks.
    
- Attempting to extract another User's private records.
    
- Deliberately exploiting an error message to obtain internal information.
    

If you discover a possible security issue, do not exploit it or access information that is not yours.

Report the issue privately to the Operator at:

[**nextstepstudiosofficial.contact@gmail.com**](mailto:nextstepstudiosofficial.contact@gmail.com)

Include a concise description of the problem and enough technical context to help reproduce it safely. Do not include passwords, tokens, or other authentication secrets.

---

## 12. Privacy and Personal Information

You must respect the privacy of other Users when using the Bot.

You must not:

- Submit another person's private information without a legitimate reason.
    
- Use the Bot to obtain information about another User without authorization.
    
- Publish private application answers or ticket conversations.
    
- Share private records outside their intended audience.
    
- Use a Bot Feature to harass, intimidate, or expose another person.
    
- Submit sensitive information that the relevant Feature does not require.
    
- Attempt to access records belonging to another User.
    

Do not assume that information submitted to a private workflow is appropriate to redistribute.

The Privacy Policy explains the information the Bot may process and how privacy requests may be submitted.

---

## 13. Files, Links, and Attachments

Where a Feature accepts files, attachments, or links, you are responsible for ensuring that the material is appropriate and that you have the right to submit it.

Do not submit:

- Malware or malicious scripts.
    
- Files intended to compromise another person's device.
    
- Phishing links.
    
- Stolen credentials.
    
- Unlawfully obtained private information.
    
- Material that infringes another person's rights.
    
- Content that violates Discord's policies.
    
- Files designed to exploit the Bot or its supporting systems.
    

The Operator may restrict or remove access to submitted material where reasonably necessary to protect the Server, Users, or Bot.

---

## 14. Circumvention and Evasion

You must not use alternate accounts, deceptive identities, or technical workarounds to evade a restriction or enforcement decision.

Examples include:

- Using another account to submit an application after being restricted from doing so.
    
- Using another account to reopen a prohibited workflow.
    
- Attempting to access a restricted Feature through a different command.
    
- Manipulating identifiers or inputs to bypass permission checks.
    
- Asking another User to perform an action that you are prohibited from performing.
    
- Exploiting a Bot error to bypass a restriction.
    

A legitimate correction, clarification, or authorized administrative action is not automatically circumvention. The context and purpose of the conduct matter.

---

## 15. Respect for Discord's Rules

All use of the Bot must comply with applicable Discord requirements.

You must not use the Bot to facilitate conduct prohibited by Discord's:

- Terms of Service.
    
- Community Guidelines.
    
- Developer Policy, where applicable.
    
- Other applicable policies and platform requirements.
    

The Operator may restrict a Feature or take Server-level action where necessary to respond to a violation or protect the Server.

Discord may independently enforce its own policies. The Operator does not control Discord's independent decisions.

---

## 16. Enforcement

Violations of this Policy may result in action under the Moderation and Enforcement Policy.

Depending on the circumstances, possible responses may include:

- An informal reminder.
    
- A warning.
    
- A formal warning.
    
- Restriction of a specific Feature.
    
- Removal or rejection of a submission.
    
- Temporary restriction from using the Bot.
    
- Referral to the Operator for review.
    
- Server-level moderation action, including removal or banning where appropriate.
    

The response may depend on:

- The seriousness of the conduct.
    
- Whether the conduct was intentional.
    
- The impact on other Users.
    
- The impact on Bot operation or data.
    
- Relevant prior conduct.
    
- The available evidence.
    
- The risk of continued harm.
    

The Operator is not required to use every lesser measure before taking a more serious action where the circumstances justify it.

The exact enforcement process is described in the Moderation and Enforcement Policy.

---

## 17. Reporting Misuse

If you believe someone is abusing the Bot, attempting unauthorized access, submitting malicious material, or misusing a Feature, report the issue through an appropriate Server support channel or contact the Operator.

**Contact:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

Where possible, include:

- The relevant Bot Feature.
    
- The approximate date and time.
    
- A description of what happened.
    
- Relevant message or submission references.
    
- Any supporting information you can safely provide.
    

Do not investigate by accessing another person's account, private records, or systems without authorization.

---

## 18. Changes to This Policy

This Policy may be updated when:

- The Bot gains or loses Features.
    
- New forms of misuse are identified.
    
- Permission systems change.
    
- Security requirements change.
    
- Discord's platform or policies change.
    
- The Operator identifies a need for clarification.
    

Substantive changes should be reflected in the document version and revision date.

Where a change materially affects Users, the Operator should provide reasonable notice through an appropriate Server channel or Bot interaction where practicable.

---

## 19. Contact Information

Questions or reports concerning this Policy may be sent to:

**Next Step Studios**  
**Operator:** Candler Shaw  
**Email:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

Do not include passwords, authentication codes, recovery codes, or unnecessary sensitive information in your message.

---

## 20. Related Policies

This Policy should be read alongside:

1. **Discord Bot Terms of Service**
    
2. **Privacy Policy**
    
3. **Community Guidelines**
    
4. **Moderation and Enforcement Policy**
    
5. **Data Retention and Deletion Policy**
    
6. **Security and Data Protection Overview**
    

Each document addresses a different aspect of using or administering the Bot. They should be kept consistent and updated when the Bot's implementation changes.

---

## 21. Draft Status and Publication Checklist

This document is a working draft for review and is not yet effective.

Before publication, the Operator should:

- Verify that the listed Bot Features accurately reflect the current implementation.
    
- Distinguish implemented Features from partially implemented and planned Features.
    
- Verify the permission requirements for administrative commands.
    
- Confirm that restricted commands cannot be used by unauthorized Users.
    
- Confirm that application and ticket workflows have appropriate access controls.
    
- Confirm that suggestion and announcement workflows cannot be abused through duplicate or repeated actions.
    
- Confirm that any cooldowns or rate limits described in the implementation are accurate.
    
- Confirm that error handling does not expose secrets or unnecessary internal information.
    
- Ensure that the Moderation and Enforcement Policy describes the available enforcement process.
    
- Ensure that the Privacy Policy accurately describes information processed by each Feature.
    
- Make this Policy accessible to Server members.
    
- Update the document version and effective date after approval.
    

**End of document.**

---

<!--
  Discord Bot Community Guidelines
  Next Step Studios - Discord bot documentation

  Version:    0.2.0
  Status:     Draft for review. Not yet effective.
  Applies to: The private Next Step Studios Discord server and conduct connected to its community activities

  Downloaded from: /policies/bot/community-guidelines

  This document is a draft for review and is not yet effective.

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Discord Bot Community Guidelines

> Expected conduct in the Next Step Studios Discord server.

**Plain-language summary:** Treat other members with basic respect. These guidelines set expectations for conduct in the private server, separate from the bot's technical rules. They do not require everyone to agree; they require reasonable cooperation and care for other people.

**Version 0.2.0** · Draft for review. Not yet effective. · Applies to: The private Next Step Studios Discord server and conduct connected to its community activities

## 1. Our Community

Next Step Studios aims to maintain a respectful, constructive, and welcoming community.

These Community Guidelines establish the standards expected of individuals participating in the Next Step Studios Discord server (the **"Server"**).

The goal is not to require everyone to think alike, agree on every subject, or interact in exactly the same way. Members may have different personalities, opinions, interests, and communication styles.

However, participation in the Server requires basic respect for other people, reasonable cooperation, and compliance with the Server's rules.

These Guidelines apply to conduct within the Server, including public channels, private support workflows, staff interactions, and other community-related activities.

They should be read alongside the Discord Bot Terms of Service, Acceptable Use Policy, and Moderation and Enforcement Policy.

---

## 2. Respect Other Members

Treat other members with basic courtesy and respect.

You must not use the Server to:

- Harass or intimidate another member.
    
- Threaten physical harm.
    
- Target someone through repeated unwanted contact.
    
- Bully, humiliate, or deliberately provoke another person.
    
- Encourage others to harass a member.
    
- Use discriminatory slurs or targeted hateful conduct.
    
- Repeatedly insult someone after being asked to stop.
    
- Create a hostile environment through sustained personal attacks.
    

Disagreement is allowed. Personal attacks are not required to express disagreement.

If another member asks you to stop a particular interaction, take that request seriously. Continuing unwanted behavior may be treated as harassment depending on the circumstances.

---

## 3. Communicate Constructively

Members are encouraged to communicate clearly and in good faith.

When participating in discussions:

- Address the subject rather than attacking the person.
    
- Avoid deliberately misrepresenting another member's statements.
    
- Do not intentionally derail conversations to provoke arguments.
    
- Give others room to participate.
    
- Avoid repeatedly posting the same message.
    
- Respect reasonable requests from authorized staff.
    
- Be willing to clarify misunderstandings.
    

A disagreement does not automatically constitute misconduct. Context, intent, frequency, and impact may matter when reviewing a concern.

---

## 4. No Harassment, Threats, or Targeted Abuse

The Server does not permit harassment or targeted abuse.

Examples include:

- Repeatedly sending unwanted messages to a member.
    
- Following someone across channels to continue an argument.
    
- Threatening a member or their family.
    
- Encouraging others to attack or intimidate a person.
    
- Sharing private information to embarrass or endanger someone.
    
- Using alternate accounts to continue unwanted contact.
    
- Coordinating harassment outside the Server because of a Server disagreement.
    
- Deliberately exploiting someone's vulnerabilities to distress them.
    

Serious threats, credible safety concerns, or targeted harassment may result in immediate escalation to the Operator.

---

## 5. Privacy and Personal Information

Respect the privacy of every member.

Do not share another person's private information without appropriate authorization.

This includes, but is not limited to:

- Home addresses.
    
- Personal telephone numbers.
    
- Private email addresses.
    
- Passwords or authentication information.
    
- Private conversations.
    
- Personal documents.
    
- Financial information.
    
- Private photographs.
    
- Other identifying information that a person has not chosen to make public.
    

Do not attempt to obtain another member's private information through deception, pressure, or unauthorized access.

Do not publish screenshots of private conversations or support interactions in a way that exposes another person's information without a legitimate reason and appropriate authorization.

If you need to report a privacy concern, use an appropriate private support method rather than publicly reposting the information.

---

## 6. Appropriate Use of Channels

Use channels for their intended subjects and purposes.

Members should:

- Read channel descriptions and pinned instructions where available.
    
- Keep discussions reasonably relevant.
    
- Avoid posting unrelated content repeatedly.
    
- Avoid flooding channels with excessive messages.
    
- Use designated support or application workflows when instructed.
    
- Avoid publishing private submissions in public channels.
    
- Follow channel-specific restrictions.
    

Authorized staff may move, remove, or redirect content when necessary to keep the Server organized.

A single accidental off-topic message is not necessarily a serious violation. Repeated disruption after reasonable direction may be treated differently.

---

## 7. Spam and Disruptive Behavior

Do not disrupt the Server through excessive or repetitive activity.

Examples include:

- Flooding channels with repeated messages.
    
- Sending unsolicited mass mentions.
    
- Repeatedly tagging staff without a legitimate reason.
    
- Posting large amounts of meaningless content.
    
- Repeatedly joining and leaving to disrupt the community.
    
- Creating duplicate support requests to overwhelm staff.
    
- Repeatedly posting the same link or advertisement.
    
- Using bots or automated accounts to flood the Server.
    
- Deliberately disrupting voice or text conversations.
    

The Operator may restrict disruptive activity even if individual messages do not appear harmful when considered separately.

---

## 8. Advertising, Promotion, and Unsolicited Solicitation

Do not use the Server to distribute unsolicited advertisements, referral links, promotional campaigns, or unrelated invitations.

Promotion may be permitted only where an authorized channel or explicit permission allows it.

Do not:

- Send unsolicited advertisements through direct messages to members based on Server membership.
    
- Repeatedly promote unrelated communities or services.
    
- Use the Server to recruit members for unrelated projects without permission.
    
- Disguise advertisements as ordinary support requests.
    
- Post deceptive giveaways, referral schemes, or suspicious offers.
    

If you are unsure whether a particular form of promotion is allowed, ask the Operator before posting it.

---

## 9. Content and Links

Content shared in the Server must comply with Discord's rules and applicable law.

Do not post:

- Malware or harmful files.
    
- Phishing links.
    
- Scams or fraudulent offers.
    
- Stolen credentials.
    
- Content intended to compromise another person's device or account.
    
- Non-consensual intimate material.
    
- Private information shared without authorization.
    
- Threats or instructions intended to facilitate harm.
    
- Material that violates applicable Discord policies.
    

Do not disguise harmful links or files to trick members into opening them.

Members should exercise reasonable caution before opening unfamiliar files or links, even when they appear to come from someone they know.

---

## 10. Discrimination and Hate

The Server does not permit targeted hateful conduct or discrimination against individuals or groups.

Members must not use slurs, threats, dehumanizing language, or targeted abuse to attack another person based on protected or personal characteristics.

This does not mean that every disagreement about a sensitive subject is automatically prohibited. Context and conduct matter.

However, disagreement does not excuse harassment, threats, or attempts to make another member feel unsafe or unwelcome through targeted abuse.

---

## 11. Impersonation and Deception

Do not impersonate:

- The Operator.
    
- A staff member.
    
- Another Server member.
    
- A Discord representative.
    
- A third-party organization.
    
- A person or organization in a way intended to mislead members.
    

Do not create a false impression that you have permissions, authority, or approval that you do not possess.

Do not fabricate screenshots, records, messages, or evidence to manipulate a dispute or moderation review.

Clearly distinguish jokes, fictional content, and roleplay from genuine statements where confusion could cause harm.

---

## 12. Respect Staff and Administrative Processes

Authorized staff members help operate and maintain the Server.

Members are expected to:

- Follow reasonable administrative instructions.
    
- Use designated support channels for questions and concerns.
    
- Avoid harassing staff over a decision.
    
- Avoid repeatedly contacting staff after receiving a clear response.
    
- Provide relevant information when reporting a problem.
    
- Avoid interfering with active reviews or administrative workflows.
    

Staff members are also expected to act responsibly and follow applicable Server policies.

A staff role does not give someone permission to harass members, disclose private information, or misuse administrative access.

Concerns about staff conduct may be raised privately with the Operator.

---

## 13. Applications and Staff Conduct

Members participating in an application or staff process must act honestly and professionally.

Applicants should:

- Answer questions truthfully.
    
- Provide relevant information.
    
- Respect reviewers.
    
- Avoid pressuring staff for an outcome.
    
- Avoid sharing another applicant's private information.
    
- Accept that an application may be declined.
    

Staff members and reviewers should:

- Treat applicant information carefully.
    
- Avoid unnecessary disclosure of application details.
    
- Review submissions fairly and responsibly.
    
- Avoid using their position for retaliation or personal gain.
    
- Avoid accessing records outside their responsibilities.
    
- Raise conflicts of interest where relevant.
    

Application and staff records are subject to the Privacy Policy and Data Retention and Deletion Policy.

---

## 14. Tickets, Reports, and Support

Support workflows should be used in good faith.

When opening a ticket or submitting a report:

- Explain the issue clearly.
    
- Provide relevant details.
    
- Avoid unnecessary sensitive information.
    
- Do not fabricate evidence.
    
- Do not use the process to harass another person.
    
- Avoid repeatedly opening duplicate requests.
    
- Respect the individuals handling the request.
    

A report does not automatically establish that the reported conduct occurred. Reports may need to be reviewed before action is taken.

---

## 15. Suggestions and Feedback

Constructive feedback is welcome.

Members may suggest improvements, identify problems, and disagree with decisions respectfully.

Suggestions should:

- Be relevant to the Server or its operation.
    
- Be expressed clearly.
    
- Avoid personal attacks.
    
- Avoid exposing private information.
    
- Avoid duplicate submissions intended to manipulate review.
    
- Respect the fact that suggestions may be declined or deferred.
    

The Operator is not required to implement every suggestion.

---

## 16. Voice and Real-Time Interactions

Where voice channels or other real-time communication Features are available, the same expectations of respect apply.

Do not:

- Deliberately disrupt voice conversations.
    
- Play excessively loud or disruptive audio.
    
- Use voice communication to harass or threaten members.
    
- Record or distribute private conversations without appropriate authorization.
    
- Repeatedly interrupt others to prevent normal participation.
    
- Use soundboards or other tools to create sustained disruption.
    

Members should respect reasonable channel-specific instructions and the privacy of other participants.

---

## 17. Conflicts and Disagreements

Disagreements are a normal part of a community.

Members should attempt to resolve ordinary disagreements respectfully.

If a discussion becomes personal or disruptive:

1. Stop escalating the argument.
    
2. Avoid continuing the dispute across multiple channels.
    
3. Use an appropriate private support method if staff assistance is needed.
    
4. Provide relevant context without exaggeration or fabricated evidence.
    
5. Allow the Operator or authorized staff to review the concern.
    

Do not encourage other members to take sides through harassment, threats, or coordinated attacks.

The Operator may intervene when a disagreement begins to disrupt the Server or harm other members.

---

## 18. Reporting Concerns

If you experience or observe a violation of these Guidelines, you may report it through an available Server support channel or contact the Operator.

**Contact:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

Where possible, include:

- A description of what happened.
    
- The relevant member or account, if known.
    
- The approximate date and time.
    
- Relevant message references or screenshots.
    
- Any additional context that may help the review.
    

Do not publicly repost private information or sensitive evidence merely to make a report.

Reports should be made honestly and in good faith. Knowingly false reports may themselves violate these Guidelines.

---

## 19. Enforcement

Violations may be addressed under the Moderation and Enforcement Policy.

Depending on the seriousness and circumstances, action may include:

- A reminder.
    
- A warning.
    
- A formal warning.
    
- Removal of content.
    
- A restriction on a particular activity.
    
- A timeout or other Discord-supported restriction.
    
- Removal from the Server.
    
- A temporary or permanent ban.
    

Serious conduct may warrant immediate action without a prior warning.

The Operator may consider the context, intent, severity, impact, relevant history, available evidence, and risk of further harm.

These Guidelines do not establish a guaranteed warning sequence.

---

## 20. Good-Faith Participation

Members are encouraged to participate in good faith.

This includes:

- Giving others a reasonable opportunity to explain themselves.
    
- Avoiding assumptions when context is unclear.
    
- Correcting genuine mistakes where appropriate.
    
- Respecting privacy.
    
- Following reasonable instructions.
    
- Reporting serious concerns responsibly.
    
- Recognizing that staff members and other Users may make mistakes.
    

The Operator may consider good-faith efforts to resolve a problem when reviewing an incident, but good intentions do not automatically excuse serious harm or repeated misconduct.

---

## 21. Changes to These Guidelines

These Guidelines may be revised as the Server develops.

Changes may be made to:

- Clarify expectations.
    
- Address new forms of disruptive conduct.
    
- Reflect changes in Discord's platform or policies.
    
- Improve consistency with the Bot's other policies.
    
- Address safety or operational concerns.
    

Substantive changes should be reflected in the document version and revision date.

Where practicable, the Operator should provide notice of material changes through an appropriate Server channel.

---

## 22. Contact Information

Questions or concerns about these Guidelines may be sent to:

**Next Step Studios**  
**Operator:** Candler Shaw  
**Email:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

Please describe the relevant issue clearly and avoid including passwords, authentication codes, or unnecessary sensitive information.

---

## 23. Related Policies

These Guidelines should be read alongside:

1. **Discord Bot Terms of Service**
    
2. **Privacy Policy**
    
3. **Acceptable Use Policy**
    
4. **Moderation and Enforcement Policy**
    
5. **Data Retention and Deletion Policy**
    
6. **Security and Data Protection Overview**
    

The Community Guidelines describe expected member conduct. The Acceptable Use Policy governs use of the Bot. The Moderation and Enforcement Policy explains how potential violations may be handled.

---

## 24. Draft Status and Publication Checklist

This document is a working draft for review and is not yet effective.

Before publication, the Operator should:

- Confirm that these Guidelines reflect the intended Server culture.
    
- Review the Guidelines against the Server's existing rules.
    
- Confirm that staff instructions and reporting methods are accurate.
    
- Ensure that the Guidelines do not conflict with Discord's requirements.
    
- Ensure that the enforcement language matches the Moderation and Enforcement Policy.
    
- Ensure that privacy-related expectations match the Privacy Policy.
    
- Make the document accessible to Server members.
    
- Update the version and effective date after approval.
    

**End of document.**

---

<!--
  Discord Bot Moderation and Enforcement Policy
  Next Step Studios - Discord bot documentation

  Version:    0.2.0
  Status:     Draft for review. Not yet effective.
  Applies to: The private Next Step Studios Discord server and moderation-related Bot workflows

  Downloaded from: /policies/bot/moderation

  This document is a draft for review and is not yet effective.

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Discord Bot Moderation and Enforcement Policy

> How moderation decisions are made and enforced.

**Plain-language summary:** Moderation should be consistent, proportionate and explained. The policy describes how reports and rule violations are reviewed, the kinds of outcomes that are possible, and how an appeal is handled.

**Version 0.2.0** · Draft for review. Not yet effective. · Applies to: The private Next Step Studios Discord server and moderation-related Bot workflows

## 1. Purpose

This Moderation and Enforcement Policy establishes the principles, procedures, and potential consequences used to address violations of the Next Step Studios Discord server's rules and applicable policies.

The policy is intended to support:

- Consistent and proportionate enforcement.
    
- Protection of Server members.
    
- Protection of the Bot and its supporting systems.
    
- Fair consideration of relevant information.
    
- Responsible handling of reports and evidence.
    
- Appropriate documentation of moderation decisions.
    
- A clear distinction between implemented and planned moderation functionality.
    

The Operator is **Candler Shaw**, operating under the public-facing name **Next Step Studios** (the "Operator").

The Discord server is private and is intended to be the single Server in which the Next Step Studios Bot operates.

This Policy applies to moderation and enforcement relating to the Server. It does not replace Discord's independent platform enforcement.

---

## 2. Scope and Related Rules

Moderation may address conduct that violates:

- Discord Bot Terms of Service.
    
- Acceptable Use Policy.
    
- Community Guidelines.
    
- Server-specific rules and instructions.
    
- Discord's applicable Terms of Service and Community Guidelines.
    
- Applicable law.
    

This Policy applies to conduct occurring within the Server and, where relevant to the safety or operation of the Server, conduct outside the Server that materially affects its members or operations.

The Operator will consider the context and relevance of off-platform conduct rather than treating every unrelated personal disagreement as a Server moderation matter.

---

## 3. Moderation Principles

Moderation decisions should be guided by the following principles.

### 3.1 Safety

The safety and reasonable well-being of Server members should be considered when responding to harassment, threats, exploitation, malicious activity, or other harmful conduct.

### 3.2 Consistency

Similar situations should be considered using consistent standards.

Consistency does not mean that every similar-looking incident must receive an identical outcome. Relevant differences in context, intent, severity, impact, evidence, and history may justify different responses.

### 3.3 Proportionality

Where practical, enforcement should be proportionate to the seriousness of the conduct and the risk it creates.

A minor first-time issue may justify a reminder, while serious or repeated misconduct may justify stronger action.

### 3.4 Fair consideration

The Operator should consider relevant evidence and context before making a decision where circumstances permit.

A report or accusation is not automatically proof of a violation.

### 3.5 Accountability

Moderation decisions should be explainable and supported by a reasonable basis.

Where records are maintained, they should be accurate, relevant, and accessible only to individuals with a legitimate administrative need.

### 3.6 Practical judgment

The Operator may take immediate action when necessary to protect members, prevent disruption, preserve evidence, or secure the Bot.

A prior warning is not required in every circumstance.

---

## 4. Who May Enforce the Rules

The Operator retains responsibility for the overall moderation and administration of the Server.

Other individuals may be authorized to perform moderation duties where the Operator has granted them appropriate permissions.

Authorization may be limited by:

- Assigned Discord roles.
    
- Bot permissions.
    
- Specific administrative responsibilities.
    
- Feature-level access controls.
    
- Instructions from the Operator.
    

A staff title does not automatically grant access to every moderation function or private record.

Individuals exercising moderation authority must:

- Act within their assigned permissions.
    
- Use moderation tools for legitimate Server purposes.
    
- Avoid retaliation or personal misuse of authority.
    
- Handle private information responsibly.
    
- Avoid fabricating or altering evidence.
    
- Report significant incidents to the Operator where appropriate.
    
- Disclose relevant conflicts of interest.
    

The Operator may review, restrict, or revoke moderation permissions where necessary.

---

## 5. Reported Violations

### 5.1 Sources of reports

Potential violations may come to the Operator's attention through:

- Reports from Server members.
    
- Staff observations.
    
- Bot-generated information.
    
- Relevant messages or records.
    
- Support tickets.
    
- Other legitimate sources.
    

The availability of a particular reporting method depends on the Server's current configuration.

### 5.2 Information that may help

A report should include as much relevant information as reasonably available, such as:

- The account involved.
    
- A description of the conduct.
    
- The approximate date and time.
    
- Relevant message links or references.
    
- Screenshots or other supporting material.
    
- Context needed to understand the incident.
    

Do not fabricate evidence or knowingly misrepresent what happened.

### 5.3 Initial review

The Operator or an authorized reviewer may assess:

- Whether the reported conduct falls within the Server's rules.
    
- Whether the available information is relevant.
    
- Whether the report appears credible.
    
- Whether additional context is needed.
    
- Whether immediate protective action is necessary.
    
- Whether the matter should be closed, monitored, or escalated.
    

### 5.4 Incomplete or unsupported reports

A report may be closed or require additional information if there is insufficient information to proceed.

An inability to verify a report does not necessarily mean that the report was intentionally false.

Knowingly fabricated reports, however, may themselves violate the Server's policies.

---

## 6. Evidence and Review

### 6.1 Relevant evidence

The Operator may consider relevant information available through legitimate means, including:

- Discord messages.
    
- Message links and identifiers.
    
- Screenshots.
    
- User-submitted reports.
    
- Ticket information.
    
- Relevant Bot records.
    
- Statements from involved individuals.
    
- Other information reasonably connected to the incident.
    

### 6.2 Context

Evidence should be considered in context where possible.

A screenshot or isolated message may not show the entire conversation. Reviewers may consider preceding or following messages, the surrounding discussion, and other relevant information.

### 6.3 Evidence integrity

Evidence must not be knowingly fabricated, materially altered to mislead, or presented in a way that deliberately hides important context.

If the authenticity of evidence is uncertain, that uncertainty should be considered.

### 6.4 Private information

Evidence may contain personal or sensitive information.

Access should be limited to individuals who need the information for the moderation matter. Evidence should not be distributed publicly merely because it was submitted to staff.

### 6.5 No guarantee of a formal investigation

Not every report will result in a full investigation.

The Operator may decide that a reminder, direct clarification, or other limited response is sufficient. Serious matters may require a more detailed review.

---

## 7. Enforcement Actions

Depending on the circumstances, the Operator may use one or more of the following actions.

### 7.1 Informal reminder

An informal reminder may be used to clarify a rule or address a minor issue without treating it as a formal warning.

### 7.2 Formal warning

A formal warning communicates that conduct has been identified as a policy violation or unacceptable behavior and that further violations may result in stronger action.

### 7.3 Content removal or restriction

Content may be removed, hidden, or otherwise restricted where reasonably necessary to address a violation or protect members.

### 7.4 Feature restriction

A User may be restricted from using a particular Bot Feature or workflow where misuse, abuse, or operational risk justifies the restriction.

### 7.5 Timeout or temporary communication restriction

Where available and appropriate, Discord-supported restrictions may be used to temporarily limit a User's ability to communicate or participate.

### 7.6 Kick or removal from the Server

A User may be removed from the Server where continued membership is not appropriate.

A kick does not necessarily prevent the individual from rejoining if the Server's configuration permits it. A separate restriction or ban may be required to prevent re-entry.

### 7.7 Temporary ban

A temporary ban may be used where a period of removal is appropriate.

The duration should be determined based on the circumstances and the Operator's judgment.

### 7.8 Permanent ban

A permanent ban may be used for serious misconduct, repeated violations, substantial safety concerns, malicious activity, or other circumstances where continued membership is not appropriate.

A permanent ban is not required to be preceded by every lesser enforcement measure.

### 7.9 Other reasonable measures

The Operator may use other measures reasonably necessary to protect the Server, members, or Bot, provided they are consistent with applicable law and Discord's requirements.

---

## 8. Factors Considered When Determining Enforcement

The Operator may consider the following factors:

- Nature of the conduct.
    
- Severity of the violation.
    
- Whether the conduct was intentional.
    
- Whether the conduct was repeated.
    
- The impact on affected members.
    
- The risk of further harm.
    
- Relevant prior moderation history.
    
- Whether the User acknowledged or corrected the behavior.
    
- Whether the User cooperated with a review.
    
- The reliability and completeness of available evidence.
    
- Any relevant mitigating or aggravating circumstances.
    

No single factor automatically determines the outcome in every case.

### 8.1 First-time violations

A first-time minor violation may be addressed with a reminder or warning.

However, serious conduct may justify immediate stronger action even if no prior violation is recorded.

### 8.2 Repeat violations

Repeated violations may justify stronger enforcement, particularly when a User has already received a clear warning or restriction.

The Operator may consider whether the repeated conduct is substantially similar to earlier conduct and whether the User had a reasonable opportunity to understand the rule.

### 8.3 Serious violations

Conduct involving credible threats, targeted harassment, malicious software, attempts to compromise systems, serious privacy violations, or other substantial risks may justify immediate action.

The Operator is not required to issue a warning before taking urgent protective action.

---

## 9. Warnings and Violation History

Where moderation records are implemented, the Operator may maintain relevant information to support consistent administration.

A record may include:

- The affected User's Discord User ID.
    
- The responsible moderator's Discord User ID.
    
- The type of action.
    
- The reason for the action.
    
- Relevant dates and timestamps.
    
- Supporting evidence references.
    
- The duration or status of a restriction.
    
- Related review or appeal information.
    

The precise record structure and retention schedule must be established before persistent moderation records are treated as operational.

The Bot's persistent moderation and infraction recordkeeping is currently planned and is not confirmed as fully implemented.

This Policy does not promise that the Bot currently maintains a complete or permanent infraction history.

---

## 10. Conflicts of Interest and Staff Conduct

A person should not use moderation authority to settle personal disputes, retaliate against another member, or obtain an unfair advantage.

Where a moderator is directly involved in an incident or has a significant personal conflict with an involved User, the Operator should consider whether another authorized person should review the matter.

The Operator may review staff moderation decisions and may reverse, modify, or correct an action where appropriate.

Staff members who misuse permissions or disclose private information may themselves be subject to administrative action.

---

## 11. Appeals and Requests for Review

### 11.1 General principle

An appeal is a request to review an eligible moderation decision.

It is not an automatic entitlement to reversal, a guarantee of a response within a particular period, or a guarantee that the original decision will be changed.

### 11.2 Appeal eligibility

The Operator may define which moderation actions are eligible for appeal and what information is required.

The exact eligibility rules, submission limits, review process, and decision authority must be finalized before a dedicated appeal Feature is enabled.

### 11.3 Planned appeal Feature

A dedicated ban appeal workflow is planned and is not currently confirmed as operational.

Until it is implemented and verified, Users should not assume that a Bot command or automated appeal process is available.

### 11.4 Review considerations

Where an appeal process is available, a reviewer may consider:

- The original moderation decision.
    
- The reason recorded for the action.
    
- Relevant evidence.
    
- The appellant's explanation.
    
- Whether relevant context was overlooked.
    
- Whether the original action was proportionate.
    
- Any material new information.
    

### 11.5 Appeal outcomes

Possible outcomes may include:

- Upholding the original decision.
    
- Reducing or modifying the action.
    
- Reversing the action.
    
- Requesting additional information.
    
- Closing the appeal without a change.
    

The final process must be documented before the appeal Feature is treated as operational.

### 11.6 Conflicts of interest

Where practical, an appeal should be reviewed by an individual who can assess the matter without an inappropriate personal conflict.

The Operator may retain final decision authority where necessary, subject to applicable law and the final appeal procedure.

---

## 12. Notifications and Communication

Where reasonably practicable, the Operator or authorized staff may inform an affected User of a moderation action and its general reason.

However:

- Not every action will necessarily result in a detailed explanation.
    
- Urgent protective action may occur before a notification can be sent.
    
- Discord delivery failures may prevent a direct message from being received.
    
- The Operator may limit information to protect other members' privacy or the integrity of a review.
    

A User should not assume that the absence of a direct message means no moderation action occurred.

Where a decision is communicated, the User should use the designated method for questions or eligible review requests rather than repeatedly contacting multiple staff members.

---

## 13. Privacy and Moderation Records

Moderation-related information may include personal information and should be handled carefully.

Access should be limited to the Operator and individuals who need the information for a legitimate moderation or administrative purpose.

Moderation information should not be:

- Publicly disclosed without an appropriate reason.
    
- Used for unrelated purposes.
    
- Shared with unauthorized individuals.
    
- Retained indefinitely without a documented justification.
    
- Altered to misrepresent an incident.
    

The Privacy Policy and Data Retention and Deletion Policy govern the handling and retention of Bot-related records.

Because persistent moderation and appeal recordkeeping are planned, the Operator must define their storage, access, retention, and deletion behavior before enabling them in production.

---

## 14. Abuse of the Moderation Process

The moderation process must not be used to harass, intimidate, or manipulate members.

Prohibited conduct includes:

- Knowingly submitting false reports.
    
- Fabricating evidence.
    
- Threatening reviewers.
    
- Attempting to influence a decision through harassment.
    
- Repeatedly submitting duplicate reports to overwhelm staff.
    
- Impersonating another person in a report or appeal.
    
- Accessing restricted moderation records.
    
- Sharing private moderation information without authorization.
    
- Retaliating against someone for making a good-faith report.
    

A good-faith report that cannot be substantiated is not automatically misconduct.

---

## 15. Urgent Situations

The Operator may take immediate action where reasonably necessary to protect:

- A member's safety.
    
- The privacy of Users.
    
- The integrity of the Server.
    
- The Bot's systems or records.
    
- The availability of critical Server functions.
    
- Evidence relevant to a serious incident.
    

Urgent action may include temporarily restricting access, removing content, limiting a Feature, or banning an account.

Where practical, the Operator should document the reason for urgent action and review whether the measure remains necessary.

---

## 16. Errors and Corrections

Moderation decisions can be made using incomplete or incorrect information.

If a material error is identified, the Operator may correct the record or reconsider the decision.

Corrections should preserve an accurate account of what happened. Where a record must be amended, the Operator should avoid silently changing historical information in a way that creates a misleading record.

The process for correcting or deleting moderation records must follow the Data Retention and Deletion Policy and applicable law.

---

## 17. No Guaranteed Enforcement Outcome

This Policy describes the general approach to moderation. It does not guarantee:

- That every reported violation will be investigated.
    
- That every report will result in action.
    
- That every User will receive a warning before stronger action.
    
- That every decision will be communicated in detail.
    
- That every moderation action will be appealable.
    
- That an appeal will be accepted or successful.
    
- That every moderation record will be retained permanently.
    

The Operator will exercise reasonable judgment based on the available information, the Server's needs, and applicable requirements.

---

## 18. Relationship with Discord Enforcement

The Operator's moderation authority applies to the private Server and Bot-operated workflows.

Discord retains independent authority to enforce its own platform rules.

A Server-level warning, timeout, kick, or ban does not determine whether Discord will take separate action, and a Discord enforcement action does not automatically determine what Server-level action the Operator will take.

Users must continue to comply with Discord's applicable policies.

---

## 19. Changes to This Policy

This Policy may be revised as moderation tools, appeal workflows, Server rules, and operational requirements develop.

Substantive revisions should be reflected in the document version and revision date.

Where practical, material changes should be communicated through an appropriate Server channel or Bot interaction.

The Operator should ensure that the actual moderation process remains consistent with the published version.

---

## 20. Contact Information

Questions or concerns about moderation and enforcement may be sent to:

**Next Step Studios**  
**Operator:** Candler Shaw  
**Email:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

When reporting a concern, provide relevant details without including passwords, authentication codes, or unnecessary sensitive information.

---

## 21. Related Policies

This Policy should be read alongside:

1. **Discord Bot Terms of Service**
    
2. **Privacy Policy**
    
3. **Acceptable Use Policy**
    
4. **Community Guidelines**
    
5. **Data Retention and Deletion Policy**
    
6. **Security and Data Protection Overview**
    

---

## 22. Implementation and Publication Checklist

This document is a working draft and is not yet effective.

Before publication, the Operator should:

### Moderation authority

- Define which roles or individuals may use each moderation function.
    
- Verify that Bot permission checks match the intended authorization model.
    
- Confirm that unauthorized Users cannot access restricted commands.
    
- Establish a process for reviewing staff misuse or conflicts of interest.
    

### Enforcement configuration

- Define the available warning and infraction types.
    
- Decide which actions are supported by the Bot and which are performed through Discord.
    
- Define any temporary restriction durations that will actually be offered.
    
- Confirm how kicks, temporary bans, and permanent bans are handled.
    
- Confirm how enforcement actions are communicated to affected Users.
    
- Define how failed notifications are handled.
    

### Records and privacy

- Verify whether persistent moderation records are implemented.
    
- Define the fields stored in each moderation record.
    
- Establish access controls.
    
- Establish retention and deletion rules.
    
- Define how corrections are recorded.
    
- Ensure that the Privacy Policy accurately describes the implementation.
    

### Appeals

- Complete the appeal workflow before describing it as operational.
    
- Define eligible decisions.
    
- Define submission requirements.
    
- Define review authority.
    
- Define conflict-of-interest handling.
    
- Define appeal outcomes and notification behavior.
    
- Establish appeal record retention and deletion rules.
    

### Publication

- Ensure this Policy matches the Server's actual rules.
    
- Ensure the Community Guidelines and Acceptable Use Policy are consistent.
    
- Make the Policy accessible to Server members.
    
- Update the version and effective date after approval.
    

**End of document.**

---

<!--
  Discord Bot Data Retention and Deletion Policy
  Next Step Studios - Discord bot documentation

  Version:    0.2.0
  Status:     Draft framework. Retention schedules and deletion procedures require implementation and verification.
  Applies to: Information processed by the Next Step Studios Discord bot in the single private Next Step Studios Discord server

  Downloaded from: /policies/bot/data-retention

  This document is a draft for review and is not yet effective.

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Discord Bot Data Retention and Deletion Policy

> How long the Discord bot retains information, and how it is deleted.

**Plain-language summary:** This is a framework, not a finished schedule. It explains the intent to keep records only as long as they are needed, review them, and delete them on request or when they are no longer required. The specific periods and procedures still need implementation and verification.

**Version 0.2.0** · Draft framework. Retention schedules and deletion procedures require implementation and verification. · Applies to: Information processed by the Next Step Studios Discord bot in the single private Next Step Studios Discord server

## 1. Purpose

This Data Retention and Deletion Policy (the **"Policy"**) describes how information processed by the Next Step Studios Discord bot (the **"Bot"**) is intended to be retained, reviewed, corrected, archived, and deleted.

It supplements the Bot's Privacy Policy and establishes a framework for preventing unnecessary or accidental long-term retention.

The Bot is operated by **Candler Shaw**, using the public-facing name **Next Step Studios** (the **"Operator"**).

The Bot is intended exclusively for one private Next Step Studios Discord server (the **"Server"**).

This Policy applies to Bot-related information, including information submitted by Users, information generated by Bot Features, and relevant operational records.

It does not govern Discord's independent data retention practices or unrelated services.

---

## 2. Core Retention Principles

### 2.1 Retain only what is reasonably necessary

Bot Data should be retained only for as long as reasonably necessary for the purpose for which it was collected, subject to applicable law and legitimate operational requirements.

The fact that information is technically easy to store does not, by itself, justify retaining it indefinitely.

### 2.2 Retention must be purpose-specific

Different categories of information serve different purposes and should not automatically share the same retention period.

For example, an unpublished announcement draft does not necessarily need to be retained for as long as an application record or a record of a significant moderation action.

### 2.3 Avoid accidental permanent records

Temporary files, drafts, intermediate workflow data, and diagnostic information should not become permanent records merely because a cleanup process was never implemented.

Each Feature should have a defined lifecycle.

### 2.4 Deletion must be practical

A retention policy is not complete merely because it says information should be deleted.

The Operator must implement and verify a process that can locate and remove the relevant information from active storage and address copies held in backups or other storage locations.

### 2.5 Do not promise unverified deletion timelines

Specific retention periods have not yet been finalized for every category of Bot Data.

Until a schedule is approved and implemented, this Policy does not promise deletion after a particular number of days, weeks, or months.

The Operator must not advertise a fixed deletion deadline that the actual system cannot reliably meet.

---

## 3. Current Storage and Implementation Context

The Bot is currently being tested on the Operator's own computer.

The current understanding of its storage arrangements is:

- Application answers and staff-related information are stored in a local database.
    
- Some temporary workflow information is stored in JSON files.
    
- Announcement history is intended to be stored in SQLite.
    
- The ticket Feature exists, but transcript generation and persistence have not been fully verified.
    
- Persistent moderation and infraction recordkeeping are planned and are not confirmed as operational.
    
- A dedicated ban appeal workflow is planned and is not confirmed as operational.
    
- The encryption-at-rest status of the local database and related files has not been confirmed.
    
- The backup lifecycle and backup-retention schedule have not been finalized.
    

This Policy records the known implementation context. It does not claim that every planned storage arrangement is already active.

The Operator must update the internal Bot Data and Feature Register whenever the implementation changes.

---

## 4. Retention Categories and Current Schedule Status

The following table identifies the major data categories and the current retention position.

|Data category|Current understanding|Retention requirement|
|---|---|---|
|Discord User IDs|Used to identify Users and associate interactions with records.|Retain only while needed for the relevant Feature, account association, or legitimate recordkeeping purpose.|
|Discord Server ID|Used to identify the Server in which the Bot operates.|Retain while required for Bot operation and configuration.|
|Usernames and display names|May be processed through Discord interactions. Persistent storage is not verified.|Determine whether they are stored. Avoid retaining them where a User ID is sufficient.|
|Channel, role, message, and interaction identifiers|May be processed where needed by individual Features.|Retain only where necessary for configuration, routing, or record association.|
|Bot configuration|Includes operational settings and mappings.|Retain while the configuration is needed. Review when Features, roles, or channels change.|
|Application answers|Stored in a local database during testing.|Establish a schedule based on application status, review needs, and legitimate recordkeeping requirements.|
|Staff information|Stored with application-related information during testing.|Establish a separate schedule where the purpose and sensitivity differ from ordinary applications.|
|Ticket conversations|Ticket Feature exists; exact persistence behavior is not verified.|Verify message storage and transcript behavior before production. Define separate rules for open tickets, closed tickets, and transcripts.|
|Ticket attachments|Exact handling is not verified.|Determine whether files are copied, stored, or retained separately. Define deletion behavior for each location.|
|Suggestion records|Suggestion functionality exists; storage and cleanup behavior must be verified.|Define retention based on submission status and operational purpose.|
|Announcement drafts|Some workflow information is understood to use temporary JSON files.|Delete when no longer needed, subject to a defined recovery or review period.|
|Announcement history|Intended to use SQLite.|Retain only while needed for publication history, administration, and accountability.|
|Moderation records|Persistent moderation and infraction records are planned.|Define severity-based schedules before enabling persistent records.|
|Appeal records|Dedicated ban appeal workflow is planned.|Define schedules for open, resolved, withdrawn, and related appeal records before enabling the Feature.|
|Technical logs|Error and operational logs may be generated.|Establish a documented, limited retention period. Exclude credentials and unnecessary User Content.|
|Backups|Backup system and lifecycle are not fully verified.|Define storage, protection, access, rotation, expiration, and deletion behavior before relying on backups in production.|

The table is a working inventory, not a claim that every category is currently stored.

---

## 5. Temporary Files and Drafts

Temporary workflow information should have a defined purpose and lifecycle.

### 5.1 Temporary announcement drafts

Announcement drafts may be stored temporarily while an announcement is prepared, reviewed, or awaiting publication.

The intended lifecycle should address:

- Draft creation.
    
- Draft editing.
    
- Approval or rejection.
    
- Successful publication.
    
- Cancellation.
    
- Expiration.
    
- Recovery following an error.
    

A draft should not remain indefinitely after its purpose has ended unless there is a documented reason to retain it.

### 5.2 Temporary JSON files

Where JSON files are used for temporary workflow state, the Operator should document:

- Which Feature creates the file.
    
- What information it contains.
    
- Whether the file includes personal information.
    
- When it is no longer needed.
    
- What event triggers cleanup.
    
- What happens if cleanup fails.
    
- Whether the file is included in backups.
    

Temporary JSON storage should not be treated as harmless merely because it is not a database.

### 5.3 Cleanup failures

If a cleanup operation fails, the Bot should report or log the failure in a way that does not expose unnecessary User information.

The Operator should investigate the failure and remove the data when it is safe and appropriate to do so.

Repeated cleanup failures should be treated as an implementation issue, not as an acceptable permanent retention method.

---

## 6. Applications and Staff Records

Application answers and staff-related information are currently understood to be stored in a local database during testing.

The Operator must establish separate retention rules for different application states where appropriate.

### 6.1 Pending applications

Pending applications may need to remain available while they are awaiting review.

They should not be retained indefinitely after the review process has ended without a documented reason.

### 6.2 Approved applications

Approved applications may contain information relevant to an ongoing staff role or administrative responsibility.

The Operator should determine which information remains necessary after approval and avoid retaining unrelated application details simply because they were originally submitted.

### 6.3 Declined applications

Declined applications should have a defined retention period based on legitimate review, administrative, and recordkeeping needs.

The Operator should consider whether the complete original submission is still necessary after the decision has been made.

### 6.4 Withdrawn applications

Where a User withdraws an application, the Operator should review whether the submission can be deleted or whether a limited record is still needed to document the withdrawal or prevent duplicate processing.

### 6.5 Staff records

Information associated with an active staff role may need to remain available while that role continues.

When the role ends, the Operator should review the information and retain only what remains necessary for legitimate administrative, security, or legal purposes.

### 6.6 Retention schedule required

The Operator must establish and document actual retention periods for pending, approved, declined, and withdrawn applications, as well as staff records.

No specific period is promised by this draft.

---

## 7. Tickets and Support Records

The ticket Feature exists, but the actual transcript-generation and persistence behavior has not been fully verified.

Before production, the Operator must determine exactly what happens to ticket information.

### 7.1 Open tickets

Information in an open ticket may need to remain available while the request is being handled.

Access should be limited to the Operator and authorized individuals responsible for the ticket.

### 7.2 Closed tickets

Closing a ticket should trigger a defined review of what information needs to remain available and for how long.

Closing a ticket should not automatically be treated as permanent deletion unless the implementation actually deletes the relevant information.

### 7.3 Transcripts

The Operator must verify:

- Whether transcripts are generated automatically.
    
- Whether a transcript is sent to a Discord channel.
    
- Whether a transcript is saved to local storage.
    
- Whether the transcript is stored in a database.
    
- Whether multiple copies are created.
    
- Whether attachments are included.
    
- Who can access the transcript.
    
- How each copy can be deleted.
    

A transcript sent to a Discord channel may be subject to Discord's platform behavior and the access permissions of that channel. Deleting a local copy does not necessarily delete a Discord message containing the transcript.

### 7.4 Ticket deletion

The Operator should establish a process for handling deletion requests involving ticket content, transcripts, attachments, and related metadata.

The process must account for each location where a copy may exist.

### 7.5 Retention schedule required

A defined schedule must be established for open tickets, closed tickets, transcripts, attachments, and related records before the ticket workflow is treated as fully documented for production.

---

## 8. Suggestions and Announcement Records

### 8.1 Suggestions

Suggestion records may be needed to track submissions, review outcomes, and administrative history.

The Operator should define retention rules for:

- Pending suggestions.
    
- Accepted suggestions.
    
- Declined suggestions.
    
- Withdrawn suggestions.
    
- Closed suggestions.
    
- Suggestions removed through an authorized cleanup process.
    

Where a suggestion is publicly published, the Operator should distinguish between the original submission record and the published Discord message.

Deleting one does not necessarily delete the other.

### 8.2 Announcement drafts

Announcement drafts should be treated as temporary workflow information unless a legitimate reason requires retention.

The Operator should define what happens to:

- Unpublished drafts.
    
- Cancelled drafts.
    
- Rejected drafts.
    
- Successfully published drafts.
    
- Failed publication attempts.
    

### 8.3 Announcement history

Announcement history is intended to be stored in SQLite.

The Operator should retain only the information reasonably needed to understand what was published, when it was published, and the relevant administrative context.

The exact fields and retention schedule must be verified.

---

## 9. Moderation and Infraction Records

Persistent moderation and infraction recordkeeping are planned.

Before implementation, the Operator must establish a retention framework that takes account of the nature of each record.

Potential categories may include:

- Warnings.
    
- Timeouts.
    
- Kicks.
    
- Temporary bans.
    
- Permanent bans.
    
- Removed content.
    
- Related evidence.
    
- Moderator notes.
    
- Corrections or review outcomes.
    

The Operator should not automatically apply one retention period to every moderation record.

Relevant considerations may include:

- Severity of the conduct.
    
- Whether the action is temporary or permanent.
    
- Whether the record is still needed to administer an active restriction.
    
- Whether there is a repeated-offense concern.
    
- Whether an appeal or review remains open.
    
- Whether a legal preservation requirement applies.
    
- Whether the information can be reduced or anonymized while preserving necessary administrative history.
    

A complete moderation history is not automatically justified merely because it may be convenient.

The actual retention schedule must be approved before persistent moderation records are enabled.

---

## 10. Ban Appeals and Review Records

A dedicated ban appeal workflow is planned and is not confirmed as operational.

Before enabling the Feature, the Operator must define retention rules for:

- Submitted appeals.
    
- Open appeals.
    
- Withdrawn appeals.
    
- Resolved appeals.
    
- Supporting evidence.
    
- Reviewer notes.
    
- Decisions.
    
- Related moderation records.
    

An appeal record may need to remain available while the appeal is being reviewed.

After resolution, the Operator should determine what information remains necessary and delete or reduce information that no longer serves a legitimate purpose.

Appeal records should not be retained indefinitely simply because the original moderation action was permanent.

The retention schedule must be documented before the Feature is treated as operational.

---

## 11. Technical Logs and Diagnostic Information

Technical logs may be useful for identifying errors, failed operations, and security concerns.

However, logs should not become an uncontrolled secondary database of User information.

### 11.1 Minimize logged information

Where practical, logs should record the information necessary to diagnose an issue without copying entire User submissions or private conversations.

### 11.2 Exclude secrets

Logs must not contain:

- Bot tokens.
    
- Passwords.
    
- API keys.
    
- Authentication codes.
    
- Recovery codes.
    
- Other credentials or authentication secrets.
    

### 11.3 Limit access

Technical logs should be accessible only to individuals who need them for maintenance or security purposes.

### 11.4 Retention period

The Operator must establish a limited, documented log-retention period.

The actual period must reflect the logging configuration and operational needs. This draft does not establish a fixed duration.

---

## 12. Backups and Recovery Copies

The backup system and lifecycle have not been fully verified.

Before production, the Operator must document:

1. What information is included in backups.
    
2. Whether databases, JSON files, transcripts, attachments, or logs are included.
    
3. Where backups are stored.
    
4. Whether backups are encrypted.
    
5. Who can access backups.
    
6. How often backups are created.
    
7. How long backups are retained.
    
8. How old backups are rotated or deleted.
    
9. How privacy requests are handled when information exists in backups.
    
10. How the Operator verifies that a restored backup does not reintroduce information that should have been deleted.
    

### 12.1 Live deletion and backup deletion

Deleting information from the active database does not necessarily remove it from older backups.

The Operator should use a defined backup-expiration or deletion process so that deleted information does not remain indefinitely in recovery copies.

### 12.2 Restoration

If a backup is restored, the Operator should consider whether it reintroduces records that were previously deleted or corrected.

Where necessary, deletion and correction records should be reapplied after restoration.

### 12.3 No unverified backup promises

This Policy does not claim that backups are currently created, encrypted, rotated, or automatically purged.

Those behaviors must be verified before being represented as operational safeguards.

---

## 13. Privacy Requests and Deletion

Users may submit privacy requests using the contact method described in the Privacy Policy.

**Contact:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

A request may seek access, correction, deletion, or clarification concerning information associated with a User.

### 13.1 Request review

The Operator should:

1. Receive the request.
    
2. Identify the relevant Discord account and records.
    
3. Verify the requester's authority where appropriate.
    
4. Search the relevant storage locations.
    
5. Determine whether the requested action is appropriate.
    
6. Identify any applicable legal or operational retention requirement.
    
7. Carry out the action where appropriate.
    
8. Document the outcome without creating unnecessary additional personal information.
    
9. Respond to the requester.
    

### 13.2 Identity verification

The Operator may request reasonable information to verify the relevant account.

A Discord User ID may help identify the correct records.

The Operator must not request passwords, account tokens, authentication codes, or recovery codes to verify a privacy request.

### 13.3 Deletion limitations

A deletion request may not always result in immediate or complete deletion.

Information may need to be retained where:

- Applicable law requires retention.
    
- A legitimate legal preservation obligation applies.
    
- A record is necessary to resolve a pending matter.
    
- Retention is necessary to protect another person's rights.
    
- The information cannot reasonably be separated from a record that must be preserved.
    

Any exception should be limited to the information and period reasonably necessary for that purpose.

### 13.4 Partial deletion

Where complete deletion is not appropriate or practical, the Operator should consider whether information can be:

- Corrected.
    
- Redacted.
    
- Separated from identifying information.
    
- Restricted from ordinary access.
    
- Retained in a reduced form.
    

### 13.5 Deletion confirmation

The Operator should not claim that information has been deleted until the relevant action has actually been completed.

Where copies exist in separate systems or backups, the response should accurately describe any remaining copies and the process for their removal.

---

## 14. Discord and Third-Party Records

The Operator can manage only records within systems under the Operator's control or authority.

Deleting a Bot database record does not necessarily delete:

- The original Discord message.
    
- A transcript sent to a Discord channel.
    
- A message stored by Discord.
    
- A copy held by another User.
    
- A record held independently by a third-party provider.
    
- A backup outside the Operator's control.
    

Users may need to contact Discord or another relevant service directly for records controlled by that service.

The Operator should not claim to have deleted information from Discord or another provider unless that deletion has actually been carried out and verified.

---

## 15. Data Minimization

The Bot should collect and retain only information reasonably necessary for its intended Features.

The Operator should periodically review:

- Whether each stored field is still necessary.
    
- Whether a User ID is sufficient instead of a username and display name.
    
- Whether entire message contents need to be retained.
    
- Whether attachments need to be retained separately.
    
- Whether temporary workflow data can be removed sooner.
    
- Whether old records can be reduced or anonymized.
    
- Whether unused Features are still retaining information.
    
- Whether logs contain unnecessary personal information.
    

New Features should be designed with data minimization in mind rather than collecting information first and deciding later whether it is needed.

---

## 16. Access and Internal Review

The Operator should review who can access each category of information.

Access should be limited according to legitimate responsibilities.

The review should consider:

- Database access.
    
- Local file access.
    
- Backup access.
    
- Ticket and transcript access.
    
- Application and staff record access.
    
- Moderation record access.
    
- Administrative command permissions.
    
- Access granted to external providers.
    

When an individual's authorization ends, their access should be removed or adjusted as appropriate.

The Operator should avoid retaining unnecessary copies of records outside the intended storage location.

---

## 17. Retention Schedule Governance

A retention schedule should be maintained internally and reviewed whenever:

- A new Feature is introduced.
    
- A Feature changes its storage behavior.
    
- A database or file format changes.
    
- The Bot moves to a different hosting arrangement.
    
- A new external provider is introduced.
    
- A privacy request reveals a deletion limitation.
    
- A security incident reveals an unexpected copy of information.
    
- Applicable legal requirements change.
    

The internal Bot Data and Feature Register should identify the retention rule for each relevant category.

The Policy Implementation Checklist should track whether the documented schedule has actually been implemented.

---

## 18. Changes to This Policy

This Policy may be updated when data storage, retention, deletion, or operational requirements change.

Substantive changes should be reflected in the document version and revision date.

Where a change materially affects Users, the Operator should provide reasonable notice through an appropriate Server channel or Bot interaction where practicable.

The published Policy should describe actual practices, not merely intended future behavior.

---

## 19. Contact Information

Questions or requests concerning data retention, deletion, or records associated with the Bot may be sent to:

**Next Step Studios**  
**Operator:** Candler Shaw  
**Email:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

For a privacy request, include your Discord User ID if safely available, the relevant Feature, and a clear description of the request.

Do not include passwords, authentication codes, or unnecessary sensitive information.

---

## 20. Related Policies

This Policy should be read alongside:

1. **Discord Bot Terms of Service**
    
2. **Privacy Policy**
    
3. **Acceptable Use Policy**
    
4. **Community Guidelines**
    
5. **Moderation and Enforcement Policy**
    
6. **Security and Data Protection Overview**
    

The Privacy Policy describes what information may be processed. This Policy explains how that information should be retained and deleted.

---

## 21. Implementation Checklist

This document is a working framework. It is not a claim that all retention and deletion mechanisms are already operational.

Before final publication, the Operator must:

### Inventory

- Identify every database used by the Bot.
    
- Identify every JSON file used for workflow storage.
    
- Identify any other local files that may contain User information.
    
- Identify every Feature that creates or modifies records.
    
- Identify whether usernames and display names are stored.
    
- Identify whether message content is stored.
    
- Identify whether attachments are stored.
    
- Identify whether ticket transcripts are generated and where they are kept.
    
- Identify all technical logs that may contain User information.
    
- Identify all backups and recovery copies.
    

### Retention schedules

- Establish an application retention schedule.
    
- Establish a staff-record retention schedule.
    
- Establish a ticket retention schedule.
    
- Establish a transcript retention schedule.
    
- Establish an attachment retention schedule.
    
- Establish a suggestion retention schedule.
    
- Establish an announcement-draft retention schedule.
    
- Establish an announcement-history retention schedule.
    
- Establish a technical-log retention schedule.
    
- Establish a moderation-record retention schedule before enabling persistent moderation records.
    
- Establish an appeal-record retention schedule before enabling the appeal Feature.
    
- Establish a backup-retention schedule.
    

### Deletion mechanisms

- Implement cleanup for temporary announcement drafts.
    
- Verify cleanup of temporary JSON files.
    
- Implement deletion or cleanup for expired workflow records.
    
- Define how application records are deleted.
    
- Define how ticket transcripts and attachments are deleted.
    
- Define how suggestion and announcement records are deleted.
    
- Define how moderation and appeal records will be deleted when those Features are implemented.
    
- Define how deletion is handled in backups.
    
- Test deletion using non-production test records.
    
- Confirm that deleted records are not unintentionally restored from backups.
    

### Governance

- Document the purpose of every stored category.
    
- Document who can access each category.
    
- Document any legal or operational retention exceptions.
    
- Add retention rules to the internal Bot Data and Feature Register.
    
- Ensure the Privacy Policy matches the actual implementation.
    
- Make this Policy accessible to Server members.
    
- Update the version and effective date after approval.
    

**End of document.**

---

<!--
  Discord Bot Security and Data Protection Overview
  Next Step Studios - Discord bot documentation

  Version:    0.2.0
  Status:     Draft for review. Not yet effective.
  Applies to: The Next Step Studios Discord bot operating in the single private Next Step Studios Discord server

  Downloaded from: /policies/bot/security

  This document is a draft for review and is not yet effective.

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Discord Bot Security and Data Protection Overview

> The security and data protection practices described for the Discord bot.

**Plain-language summary:** The overview describes least-privilege access, restricted administrative access, secrets kept out of source, and the current single-server context. It also identifies safeguards that are not yet claimed or verified, rather than presenting them as finished.

**Version 0.2.0** · Draft for review. Not yet effective. · Applies to: The Next Step Studios Discord bot operating in the single private Next Step Studios Discord server

## 1. Purpose

Next Step Studios takes the security and responsible handling of information processed by its Discord bot seriously.

This Security and Data Protection Overview (the **"Overview"**) explains the general principles guiding the protection of Bot-related information, the current operating context, and the safeguards that should be maintained as the Bot develops.

The Bot is operated by **Candler Shaw**, using the public-facing name **Next Step Studios** (the **"Operator"**).

The Bot is intended exclusively for one private Next Step Studios Discord server (the **"Server"**).

This document is intended for Server members and other individuals who want to understand the Operator's general approach to security.

It is not a technical security manual and does not disclose sensitive internal configuration, credentials, infrastructure details, or incident-response procedures.

---

## 2. Current Operating Context

The Bot is under development and testing.

Its current testing arrangement involves hosting it on the Operator's own computer rather than relying on a confirmed production hosting provider.

The current understanding is:

- Application answers and staff-related information are stored in a local database.
    
- Some temporary workflow information is stored in JSON files.
    
- Announcement history is intended to be stored in SQLite.
    
- Ticket transcript generation and persistence have not been fully verified.
    
- Persistent moderation and infraction recordkeeping are planned.
    
- A dedicated ban appeal workflow is planned.
    
- The encryption-at-rest status of the local database and related files has not been confirmed.
    
- The backup lifecycle and backup-retention schedule have not been finalized.
    

These details are included to avoid suggesting that the Bot already operates with a mature production security environment.

The Operator must verify the actual implementation before making stronger public security commitments.

---

## 3. Security Principles

The Operator's intended security approach is based on the following principles.

### 3.1 Access limitation

Information should be accessible only to the Operator and individuals who have a legitimate reason and appropriate authorization to access it.

Server membership or a general staff role should not automatically provide access to every private record.

### 3.2 Data minimization

The Bot should process and retain only the information reasonably necessary for its intended Features.

Unnecessary personal information should not be collected or retained merely because it is technically available.

### 3.3 Protection of credentials

Bot tokens, passwords, API keys, and other authentication secrets must be protected.

They should not be included in public documents, ordinary User-facing messages, or logs that do not require them.

### 3.4 Responsible storage

Databases, temporary files, logs, and backups should be protected according to the sensitivity of the information they contain.

A local file or database is not automatically secure simply because it is stored on a computer controlled by the Operator.

### 3.5 Controlled changes

Changes to the Bot's code, permissions, storage, and configuration should be reviewed and tested to reduce the risk of introducing security problems.

### 3.6 Accurate disclosure

The Operator should describe security measures honestly.

A safeguard should not be represented as implemented merely because it is planned, recommended, or supported by the underlying software.

---

## 4. Access to Bot Data

The current confirmed access arrangement is that the Operator is authorized to review stored User information for legitimate Bot administration, application review, troubleshooting, and related responsibilities.

Access to information should be limited according to the purpose of each Feature.

For example:

- Application information should be accessible to individuals responsible for application review.
    
- Ticket information should be accessible to individuals responsible for handling the relevant ticket.
    
- Administrative records should be accessible only to individuals with the required permissions.
    
- Technical records should be accessible only to individuals who need them for maintenance or security purposes.
    

Any expansion of access beyond the current Operator-only arrangement should be deliberate and supported by appropriate permissions.

The Operator should review access when responsibilities change or when someone no longer needs access.

---

## 5. Storage and Data Protection

### 5.1 Local testing environment

The Bot is currently being tested on the Operator's own computer.

This means that the security of the testing environment depends in part on the security of that computer, its user accounts, storage, operating system, and access controls.

Local storage should not be interpreted as a guarantee that information cannot be accessed by another person.

### 5.2 Databases and files

The Bot's development and testing arrangement includes SQLite and JSON-based storage for certain workflows.

The security of these records depends on the actual configuration of the storage location, file permissions, device security, backups, and other safeguards.

### 5.3 Encryption

The encryption-at-rest status of the Bot's local database and related files has not been confirmed for this draft.

Accordingly, this document does not claim that every database, JSON file, transcript, log, or backup is encrypted at rest.

The Operator must verify the applicable requirements and implement the necessary safeguards before production use.

### 5.4 Backups

The backup system and its lifecycle have not been fully verified.

Before relying on backups for production recovery, the Operator should establish:

- What information is backed up.
    
- Where backups are stored.
    
- Who can access them.
    
- How backups are protected.
    
- How long they are retained.
    
- How outdated backups are removed.
    
- How deletion requests are handled in relation to backups.
    

### 5.5 Temporary information

Temporary workflow data should not remain indefinitely after its purpose has ended.

Temporary files, announcement drafts, and other intermediate records should have defined cleanup behavior.

Cleanup mechanisms must be tested rather than assumed to work.

---

## 6. Credentials and Administrative Access

Authentication secrets are particularly sensitive.

The Operator should protect:

- Discord bot tokens.
    
- API keys.
    
- Database credentials, if used.
    
- Hosting credentials, if applicable.
    
- Administrative account credentials.
    
- Other secrets that could allow unauthorized access.
    

Credentials should not be placed in public repositories, policy documents, screenshots, support requests, or ordinary diagnostic messages.

Where a credential may have been exposed, the Operator should assess whether it needs to be revoked or rotated.

The Bot's permissions should follow the principle of least privilege: the Bot should receive only the Discord permissions reasonably required for its intended Features.

---

## 7. Development and AI-Assisted Work

The Operator may use AI-assisted development tools to help create, review, troubleshoot, or improve the Bot's software.

This does not mean that private User information should be shared with those tools.

The Operator should use:

- Synthetic test data.
    
- Redacted examples.
    
- Non-identifying error messages.
    
- Technical descriptions that do not reveal private User submissions.
    

Identifiable application answers, private ticket conversations, appeal materials, and other private User records should not be supplied to an AI service merely because that service is being used to assist with software development.

If a future Feature directly integrates an AI service or sends Bot Data to an external AI provider, the data flow must be assessed and disclosed before the integration is enabled.

---

## 8. Software Maintenance and Updates

The Bot is software that requires ongoing maintenance.

The Operator should:

- Review code changes before deployment.
    
- Test important workflows.
    
- Keep dependencies reasonably current.
    
- Review permission changes.
    
- Investigate unexpected errors.
    
- Avoid exposing internal configuration through error messages.
    
- Preserve data integrity during database changes.
    
- Review changes that affect personal information.
    
- Maintain appropriate recovery procedures.
    

Not every software update can be guaranteed to be free of defects.

If an update introduces a problem, the Operator should take reasonable steps to investigate and correct it.

---

## 9. Discord Platform Security

The Bot relies on Discord's platform and APIs.

The Operator does not control Discord's internal infrastructure, account security systems, platform availability, or independent data practices.

Users should:

- Protect their Discord accounts.
    
- Use strong, unique credentials.
    
- Enable available account security protections.
    
- Never share passwords or authentication codes.
    
- Be cautious of suspicious links and files.
    
- Report suspected account compromise through Discord's official support channels.
    

The Operator will not ask Users to provide their Discord password, account token, or authentication codes as part of a Bot support or privacy request.

---

## 10. Reporting a Security Concern

If you believe you have discovered a security issue involving the Bot, report it privately to the Operator.

**Security contact:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

Please provide:

- A concise description of the issue.
    
- The affected Bot Feature, if known.
    
- The approximate date and time.
    
- The steps needed to understand or safely reproduce the issue, if available.
    
- Any relevant error message or non-sensitive technical information.
    

Do not:

- Exploit the issue beyond what is reasonably necessary to demonstrate it.
    
- Access another person's private records.
    
- Attempt to extract credentials or tokens.
    
- Disrupt the Bot or Server.
    
- Publish sensitive details before the Operator has had a reasonable opportunity to assess the report.
    

Do not include passwords, API keys, Bot tokens, authentication codes, or other secrets in a security report.

The Operator may request additional non-sensitive information to understand the concern.

---

## 11. Security Incidents

A security incident may involve suspected or confirmed:

- Unauthorized access.
    
- Unauthorized disclosure.
    
- Loss of stored information.
    
- Unauthorized modification of records.
    
- Compromised credentials.
    
- Malicious software.
    
- Exploitation of a software vulnerability.
    
- Unexpected exposure of private User information.
    

If the Operator becomes aware of a suspected or confirmed incident, the Operator should assess the situation and take reasonable steps to:

1. Understand what happened.
    
2. Limit ongoing exposure or unauthorized access.
    
3. Protect affected systems and records.
    
4. Determine what information may be involved.
    
5. Preserve relevant information needed for investigation.
    
6. Correct the underlying issue where possible.
    
7. Determine whether Users, Discord, or another party must be notified.
    
8. Follow applicable legal and contractual obligations.
    

Not every technical error constitutes a personal-data breach. The circumstances and information involved must be assessed.

The detailed internal procedures for responding to incidents are maintained separately and are not included in this public Overview.

---

## 12. User Responsibilities

Users also play a role in protecting their information.

You should:

- Avoid submitting information that a Feature does not require.
    
- Never send passwords or authentication codes through the Bot.
    
- Avoid sharing another person's private information.
    
- Use the Bot only for its intended purpose.
    
- Report suspicious Bot behavior.
    
- Report suspected unauthorized access.
    
- Avoid opening suspicious files or links.
    
- Contact the Operator if you believe a private submission has been exposed.
    

Users should not attempt to investigate security incidents by accessing systems or records without authorization.

---

## 13. Security Limitations

The Operator cannot guarantee that the Bot, Discord, a computer, a database, or any connected service will be completely secure or continuously available.

Potential risks include:

- Software defects.
    
- Incorrect permissions.
    
- Human error.
    
- Device compromise.
    
- Credential exposure.
    
- Internet or platform outages.
    
- Unauthorized access.
    
- Storage failures.
    
- Vulnerabilities in third-party software.
    

The Operator will work to reduce these risks through reasonable safeguards and maintenance, but no system can be represented as risk-free.

---

## 14. Changes to This Overview

This Overview may be updated when:

- The Bot moves to a different hosting arrangement.
    
- Storage or backup systems change.
    
- Security controls are implemented or materially changed.
    
- External service providers are introduced.
    
- New Features create additional security considerations.
    
- A security review identifies a need for clarification.
    
- Applicable requirements change.
    

Substantive revisions should be reflected in the document version and revision date.

The published document should describe the actual security posture rather than planned or unverified measures.

---

## 15. Contact Information

Questions or concerns about the security of the Bot may be sent to:

**Next Step Studios**  
**Operator:** Candler Shaw  
**Email:** [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com)

For security reports, use a clear subject line such as:

**Security Concern - Next Step Studios Discord Bot**

Do not include passwords, authentication codes, API keys, Bot tokens, or other authentication secrets.

---

## 16. Related Policies

This Overview should be read alongside:

1. **Discord Bot Terms of Service**
    
2. **Privacy Policy**
    
3. **Acceptable Use Policy**
    
4. **Community Guidelines**
    
5. **Moderation and Enforcement Policy**
    
6. **Data Retention and Deletion Policy**
    

The Privacy Policy describes the information the Bot may process. The Data Retention and Deletion Policy explains how records should be retained and removed. This Overview describes the general approach to protecting those records.

---

## 17. Draft Status and Publication Checklist

This document is a working draft for review.

Before publication, the Operator should:

- Verify the current hosting arrangement.
    
- Verify which local databases and files contain User information.
    
- Verify encryption-at-rest requirements and implementation.
    
- Verify database and file access permissions.
    
- Review Bot permission requirements.
    
- Review credential and secret handling.
    
- Verify whether backups exist and how they are protected.
    
- Establish backup rotation and deletion procedures.
    
- Review technical logging for unnecessary personal information.
    
- Confirm that private User submissions are not sent to AI services as part of ordinary development assistance.
    
- Identify external service providers, if any.
    
- Establish an incident-response process.
    
- Confirm applicable Discord reporting obligations.
    
- Ensure that the Privacy Policy accurately describes security and storage practices.
    
- Make this Overview accessible to Server members.
    
- Update the version and effective date after approval.
    

**End of document.**

---

<!--
  Website Privacy Notice
  Next Step Studios - website documentation

  Version:    1.0.0
  Status:     Current notice. Describes the published website.
  Applies to: The Next Step Studios website and the local Step assistant

  Downloaded from: /policies/website/privacy

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Website Privacy Notice

> What this website collects, how the contact form and Step work, and what the site deliberately does not do.

**Plain-language summary:** This website has no accounts, analytics, advertising or tracking cookies. The contact form stores what you type, plus a one-way hash of your network address for rate limiting. Your theme choice stays in your browser. Step answers from local files and does not keep the conversation. The hosting provider keeps ordinary request logs.

**Version 1.0.0** · Current notice. Describes the published website. · Applies to: The Next Step Studios website and the local Step assistant

## 1. Scope

This notice covers the public Next Step Studios website and the assistant built into it. It is a separate document from the [Discord Bot Privacy Policy](/policies/bot/privacy), which covers the bot operating in one private Discord server.

Discord, GitHub and the studio's email provider process information under their own terms. This notice does not describe their internal practices.

## 2. The short version

There are no accounts and no analytics. The only information the site collects is what you type into the contact form, plus the theme you choose to look at it in. Step, the assistant, answers questions in your browser and does not collect them. Nothing is sold, shared for advertising, or used to build a profile.

## 3. The contact form

When you send a message, the form records:

- the name you enter;
- the email address you enter, used to reply;
- the subject you choose and the message you write;
- the time the message arrived;
- a one-way hash of your network address, used only to rate-limit repeated submissions.

The raw network address is not stored with the message. The hash cannot be turned back into an address by the studio.

Messages are stored by a small contact service run for the studio, not by an advertising or analytics provider. They are kept while the matter they concern is open and deleted from the inbox once it is resolved, or sooner if you ask. A message can be deleted individually, permanently, from the inbox. There is no automated expiry yet, and this notice will say so when there is one.

To have a message deleted, send a new message or email [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com) with enough detail to identify it. See [privacy requests](/contact#privacy-requests).

## 4. Your theme choice

The light/dark toggle stores one value in your browser's local storage under the name `nss-theme`. It records only “light” or “dark”. It is never sent to the server, and clearing site data removes it.

Reading preferences on policy pages are stored the same way, under `nss-reading-size` and `nss-reading-width`. They also stay in the browser.

## 5. Step, the local assistant

**Step** is the assistant in the bottom-right corner. When it opens, it loads two static files from this site: a curated fact file and the same full-text index used by the Search page. Your question is matched against that content in your browser.

The question is not sent to an AI service, a model or an API, and it is not put in a URL. The conversation is held in memory only: it is not written to local storage or a cookie, and it is discarded when you reload or close the page. The static-file requests are ordinary page requests and do not contain your question.

Step can offer links to public pages and to the contact form. If it cannot find an answer in the public pages, it says so rather than inventing one.

## 6. What the site does not do

Specifically, the website does not use:

- analytics, statistics or audience-measurement services;
- advertising, advertising pixels or affiliate tracking;
- session recording, heatmaps or fingerprinting;
- third-party embeds, widgets or social plugins;
- third-party fonts, scripts or content delivery networks;
- tracking cookies. Visitors receive no cookies from this site at all.

The fonts are served from the site itself, and every page is a pre-built file. The private contact inbox is different: it sets one session cookie, and only after the operator signs in. Visitors never receive it.

## 7. The status feed

The [status page](/status) asks GitHub for a small JSON file that records the bot's recent checks. That request goes to `raw.githubusercontent.com`, not to this site, and it is the only request a page makes to another host on its own. The contact form talks to the studio's contact service only when you submit it.

GitHub necessarily receives your network address, browser user agent and the time of the request to serve the feed. The page sends no cookie and no identifier of its own. If the request fails, the page falls back to the copy of the file built with the site.

## 8. Hosting and technical logs

The site is served by a hosting provider, which necessarily processes network requests to deliver pages. Like most hosting, this may involve standard request logs — such as the requesting IP address, the browser's user agent, the requested page, and a timestamp — kept by the provider for delivery, security and troubleshooting.

These logs are not used by the studio for profiling, advertising or tracking, and this site does not combine them with any other information. The exact logging and retention behaviour of the hosting provider is set by that provider rather than by this website.

## 9. Email

If you email [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com), the studio receives your email address, the contents of your message, and anything you choose to attach, and uses them to read and answer your message. Email is handled by the third-party email provider that hosts that mailbox, under its own terms.

## 10. What this notice does not claim

This notice describes what the website actually does. It is not a legal opinion and does not claim compliance with any particular law or regulation. If the site later adds a feature that collects new information — accounts, analytics, a different form — this notice will be rewritten before that feature goes live.

## 11. Changes

This notice is versioned with the rest of the policy set. A material change to what the site collects or sends is recorded as a new version, and the previous text remains available in the version history.

## 12. Contact

Questions about this notice, or about the website, go to [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com). Requests concerning information held by the Discord bot are handled through the same address — see [privacy requests](/contact#privacy-requests).

---

<!--
  Website Terms of Use
  Next Step Studios - website documentation

  Version:    0.1.0
  Status:     Draft for review. Not yet effective.
  Applies to: The public Next Step Studios website

  Downloaded from: /policies/website/terms

  This document is a draft for review and is not yet effective.

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Website Terms of Use

> The intended rules for using this website: acceptable use, intellectual property, downloads, external links and liability.

**Plain-language summary:** These draft terms describe how the website may be used, what the studio owns, how downloads and external links work, and the limits of what the site promises. They are published for review and are not yet an agreement you are bound by.

**Version 0.1.0** · Draft for review. Not yet effective. · Applies to: The public Next Step Studios website

## 1. About these terms

These terms describe the intended rules for using the Next Step Studios website. They are a draft published for review. They are not yet effective, they do not create a binding agreement, and nothing in them is legal advice.

The site is operated by **Candler Shaw** under the public-facing name **Next Step Studios**. The studio is not a registered company.

## 2. What this site is

This is an informational website about the studio, its projects and its public documents. It has no accounts, no purchases, no user profiles and no public posting. Nothing on the site is an offer, a release date, a commitment to deliver a feature, or a promise that a project will be finished.

Descriptions of planned work are descriptions of intent. A status label records where something stands today; it does not reserve anything for you or guarantee a future release.

## 3. Acceptable use

You may read, link to and download from the site for lawful purposes. You must not:

- attempt to gain unauthorised access to the site, its hosting, the contact service or another person's information;
- interfere with the site's availability, including through sustained automated requests that impose a load beyond ordinary reading;
- upload or send malicious code, phishing content or material that is unlawful;
- submit another person's private information through the contact form without their permission;
- impersonate the studio, its operator or a contributor, or misrepresent an affiliation with them;
- use the studio's name or marks in a way that suggests endorsement of a product, service or statement.

The contact form exists for genuine enquiries. It must not be used for bulk advertising, harassment or repeated messages after a clear request to stop.

## 4. Intellectual property

The original text, layout, design, source code, logo and artwork on this site belong to the studio or are used with permission. Third-party names, logos and trademarks belong to their respective owners.

The brand marks may be used under the rules in the [press and brand guidelines](/press#guidelines). Those rules describe permitted editorial use and do not grant a general licence to alter the marks or imply endorsement.

Nothing on this site grants you ownership of its content. Quoting a short passage with attribution and a link is permitted; republishing a whole page as your own is not.

## 5. Downloads

Policy documents, the command cheatsheet and the brand kit are provided for reading, archiving and reference. A downloaded copy can go out of date: the version published on this site is the authoritative one.

Files are provided as they are. The studio does not promise that a download will be uninterrupted, error-free or compatible with every device.

## 6. External links

The site links to Discord, GitHub and other third-party services. Those services have their own terms and privacy practices, and the studio does not control them. A link is not an endorsement of everything a third-party site contains.

## 7. Availability and changes

The site is a static build served by a hosting provider. It may be changed, moved, partially unavailable or taken offline without notice. No uptime, response time or continued availability is promised.

Pages, documents and downloads may be revised. Where a policy document changes materially, a new version is recorded and the previous text remains available in its version history.

## 8. No warranty

To the extent permitted by law, the site and its content are provided **as is** and **as available**, without warranties of any kind, whether express or implied. The studio does not warrant that the content is complete, accurate or suitable for a particular purpose.

The documents on this site describe the studio's practices and intentions. They are not legal, security or professional advice for you, and you should not rely on them as such.

## 9. Limitation of liability

To the extent permitted by law, the studio is not liable for indirect, incidental or consequential loss arising from your use of the site, from reliance on its content, or from a download obtained through it.

Nothing in these terms excludes or limits a liability that cannot lawfully be excluded or limited.

## 10. Privacy

The [Website Privacy Notice](/policies/website/privacy) describes what the site collects and does not collect. It is a separate document and is not replaced by these terms.

## 11. Reporting a problem

Problems with the site, including broken links, security concerns and copyright complaints, go to [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com). The [security overview](/policies/website/security) and [copyright notice](/policies/website/copyright) explain what to include.

## 12. Status of these terms

These terms are version 0.1.0 and are marked **draft for review**. They have no effective date. They are published so the intended rules are visible and can be reviewed before they are relied upon.

If they are later made effective, the version, effective date and any material changes will be recorded on this page and in the version history.

---

<!--
  Website Copyright and Takedown Notice
  Next Step Studios - website documentation

  Version:    0.1.0
  Status:     Draft for review. Not yet effective.
  Applies to: Content published on the Next Step Studios website

  Downloaded from: /policies/website/copyright

  This document is a draft for review and is not yet effective.

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Website Copyright and Takedown Notice

> Who owns the content on this site, what reuse is permitted, and how to report material you believe infringes your rights.

**Plain-language summary:** The studio owns the original content on this site. You may read, link, quote briefly with attribution, and use the brand kit under the press guidelines. If you believe something here infringes your copyright, email the studio with the details listed in this notice; the material will be reviewed and may be removed.

**Version 0.1.0** · Draft for review. Not yet effective. · Applies to: Content published on the Next Step Studios website

## 1. What this notice covers

This notice explains who owns the material published on the Next Step Studios website, what you may do with it, and how to report material you believe infringes a copyright or other right.

It is a draft for review. It is not legal advice, and it does not claim compliance with any particular copyright regime.

## 2. Who owns what

The original text, page design, source code, logo, brand marks and artwork created for this site belong to the studio or are used with permission.

Some material may belong to someone else: third-party names, logos, trademarks, quoted passages and linked resources remain the property of their owners. Their appearance here does not transfer ownership.

## 3. What you may do

Without asking, you may:

- read the site and link to any public page;
- quote a short passage with clear attribution and a link to the page it came from;
- download policy documents, the command cheatsheet and the brand kit for personal, editorial or reference use;
- use the brand marks under the rules in the [press and brand guidelines](/press#guidelines);
- print a page for your own reading.

You may not, without written permission:

- republish a whole page or a substantial part of the site as your own;
- sell the content or include it in a paid product;
- alter the brand marks or use them in merchandise;
- use the studio's name or marks to suggest endorsement of something the studio has not endorsed;
- remove attribution or copyright notices from a downloaded copy.

## 4. Reporting infringement

If you believe material on this site infringes your copyright, email [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com) with the subject **Copyright notice** and include:

- your name and contact address;
- the work you say is infringed, with enough detail to identify it;
- the exact URL or page on this site where the material appears;
- an explanation of why you believe the use is not authorised;
- a statement that the information in your notice is accurate and that you are the rights holder or authorised to act for them.

Please do not include identity documents, passwords or other sensitive material. Send only what is needed to identify the work and the page.

## 5. What happens next

The studio will review the notice and may remove or restrict the material while it is checked, contact the person who supplied it, or ask for more information.

No fixed response time is promised, and sending a notice does not guarantee a particular outcome. Frivolous or knowingly false notices may be refused.

## 6. If material was removed in error

If material you supplied was removed and you believe it was lawful, email the same address with the subject **Copyright counter-notice**, identify the removed material and explain why you believe it may be restored.

The studio will review the explanation before restoring anything.

## 7. Other complaints

Complaints that are not about copyright — impersonation, trademarks, privacy or a security issue — can use the same address. Mark the subject so it reaches the right place: **Trademark**, **Privacy** or **Security**.

## 8. Status of this notice

This notice is version 0.1.0 and is marked **draft for review**. It has no effective date. It is published so the intended process is visible before it is relied upon.

If it is later made effective, the version, effective date and any material changes will be recorded on this page and in the version history.

---

<!--
  Website Security Overview
  Next Step Studios - website documentation

  Version:    1.0.0
  Status:     Current overview. Describes the published website.
  Applies to: The public Next Step Studios website and its contact service

  Downloaded from: /policies/website/security

  This is an offline copy. The version published at the address above is
  the authoritative one, and this copy may become out of date.

  Next Step Studios, operated by Candler Shaw.
  Contact: nextstepstudiosofficial.contact@gmail.com
-->

# Website Security Overview

> How this website is built and served, what runs in the browser, and how to report a security problem.

**Plain-language summary:** The site is a pre-built static website served by GitHub Pages. There are no accounts, no database and no server-side application. The contact form uses a small separate service. The page runs no analytics, third-party scripts or third-party fonts. The studio makes no claim of a formal audit or certification.

**Version 1.0.0** · Current overview. Describes the published website. · Applies to: The public Next Step Studios website and its contact service

## 1. Scope

This overview describes the public Next Step Studios website and the small contact service that receives its form. It does not describe the Discord bot, which has its own [Security and Data Protection Overview](/policies/bot/security), or the internal systems of Discord, GitHub and the email provider.

It describes the site as it is built today. It is not a certification, an audit report or a guarantee.

## 2. How the site is built

The site is generated by Astro into plain HTML, CSS and a small amount of JavaScript. Every page is a pre-built file. There is no server-side application, no database, no login and no session for visitors.

The source is version-controlled, and the public build is produced from that source. Dependencies are declared in a lockfile so a build resolves the same versions rather than whatever happens to be newest.

## 3. Transport and hosting

The site is served over HTTPS by GitHub Pages. The hosting provider terminates TLS, serves the files and necessarily processes network requests. Its own logging and retention practices are set by GitHub, not by this website.

The studio does not control GitHub's infrastructure and does not claim to audit it.

## 4. What runs in the browser

The page loads its fonts, styles and scripts from this site. It does not load analytics, advertising, third-party embeds, third-party fonts or a client-side framework.

Three things use browser storage or make a separate request:

- the light/dark theme choice, stored in local storage under `nss-theme`;
- policy reading preferences, stored under `nss-reading-size` and `nss-reading-width`;
- the status page's read-only request to `raw.githubusercontent.com` for the bot's status file.

Step, the assistant, loads two static files from this site and answers in the browser. It sends no question to a server and keeps no conversation after the page is reloaded.

## 5. The contact form

The form posts to a small contact service operated for the studio. That service stores the message, a one-way hash of the network address for rate limiting, and the time it arrived. The raw network address is not stored with the message.

The private inbox sets one session cookie after the operator signs in. Visitors never receive that cookie. The inbox is not part of the static site and has no public registration.

## 6. Secrets and access

Secrets used by the contact service are kept outside the public repository and are not included in the browser build. The site itself needs no API key, database credential or user account to render.

Access to the private inbox is limited to the operator. The studio does not publish an administrative interface for the public site because the public site has no accounts or editable content.

## 7. What this overview does not claim

The studio does not claim:

- a formal security audit, penetration test or certification;
- compliance with a particular security standard or legal regime;
- that the site is impossible to compromise;
- that GitHub, Discord or the email provider are free of defects;
- a bug bounty, a response-time guarantee or payment for a report.

The site is small and static, which removes whole classes of risk. It does not remove every risk.

## 8. Reporting a security problem

Email [nextstepstudiosofficial.contact@gmail.com](mailto:nextstepstudiosofficial.contact@gmail.com) with the subject **Security** and enough detail to reproduce the issue. Include the page or endpoint, what you observed, and any steps needed to see it.

Please do not test against the live contact service, attempt to access another person's information, or post the issue publicly before it has been reviewed. There is no bounty programme, and none is implied. The studio will read the report, but no response time is promised.

The same contact address is published in the machine-readable [`security.txt`](/.well-known/security.txt).

## 9. Changes

This overview is versioned with the rest of the website documents. A material change to how the site is built, served or secured is recorded as a new version, and the previous text remains available in the version history.
