Next Step Studios — complete policy set
Generated 2026-11-21

WHAT IS IN HERE

  README.txt              This file.
  all-policies.md         Every document in one file, in publishing order.
  policies/<slug>.md      One Markdown file per document, with the same
                          attribution header as the individual download.

DOCUMENTS

  terms                    Terms of Service — v0.2.0
  privacy                  Privacy Policy — v0.2.0
  acceptable-use           Acceptable Use Policy — v0.2.0
  community-guidelines     Community Guidelines — v0.2.0
  moderation               Moderation and Enforcement Policy — v0.2.0
  data-retention           Data Retention and Deletion Policy — v0.2.0
  security                 Security and Data Protection Overview — v0.2.0

STATUS

All 7 documents are drafts for review and are not yet effective.
Downloading this archive does not change their status. Nothing in this
archive claims legal compliance.

These documents cover the Next Step Studios Discord bot only. They do not
cover the website and are not a website privacy policy.

The authoritative version of each document is the page at
https://next-step-studios-official.github.io/policies/bot/<slug>, and the
individual downloads are available from /downloads. A copy in this ZIP can
become out of date.

Next Step Studios, operated by Candler Shaw.
Contact: nextstepstudiosofficial.contact@gmail.com
