Next Step Studios — complete policy set
Generated 2026-11-24

WHAT IS IN HERE

  README.txt              This file.
  all-policies.md         Every document in one file, in publishing order.
  bot/<slug>.md           The Discord bot documents.
  website/<slug>.md       The website documents.
  game/<slug>.md          The Places Left Behind documents, when published.

DOCUMENTS

  bot      terms                    Terms of Service — v0.2.0
  bot      privacy                  Privacy Policy — v0.2.0
  bot      acceptable-use           Acceptable Use Policy — v0.2.0
  bot      community-guidelines     Community Guidelines — v0.2.0
  bot      moderation               Moderation and Enforcement Policy — v0.2.0
  bot      data-retention           Data Retention and Deletion Policy — v0.2.0
  bot      security                 Security and Data Protection Overview — v0.2.0
  website  privacy                  Website Privacy Notice — v1.0.0
  website  terms                    Website Terms of Use — v0.1.0
  website  copyright                Copyright and Takedown — v0.2.0
  website  security                 Security Overview — v1.0.0

STATUS

9 of 11 documents are drafts for review and are not yet effective.
The website privacy notice and security overview describe the published site
and are current. Downloading this archive does not change any status, and
nothing in this archive claims legal compliance.

SCOPES

These documents cover separate things. The bot set covers the Next Step
Studios Discord bot operating in one private server. The website set covers
this public site. Places Left Behind has its own game scope in preparation;
no game document is included here until the real document is published.
They are not interchangeable, and one is not a substitute for another.

The authoritative version of each document is the page at
https://next-step-studios-official.github.io/policies/<scope>/<slug>, and
the individual downloads are available from /downloads. A copy in this ZIP
can become out of date.

Copyright © 2026 Candler Shaw. All rights reserved. Developed under the name Next Step Studios.
Contact: nextstepstudiosofficial.contact@gmail.com
